-- Restrict execution of an existing helper RPC that should not be exposed to client roles.
-- Add covering indexes for foreign keys flagged by the database advisor.
BEGIN;
REVOKE EXECUTE ON FUNCTION public.rls_auto_enable() FROM PUBLIC, anon, authenticated;
CREATE INDEX IF NOT EXISTS ad_campaigns_created_by_idx ON public.ad_campaigns(created_by);
CREATE INDEX IF NOT EXISTS audit_logs_actor_user_id_idx ON public.audit_logs(actor_user_id);
CREATE INDEX IF NOT EXISTS revenue_records_session_id_idx ON public.revenue_records(session_id);
CREATE INDEX IF NOT EXISTS support_tickets_assigned_to_idx ON public.support_tickets(assigned_to);
CREATE INDEX IF NOT EXISTS verified_ad_events_session_id_idx ON public.verified_ad_events(session_id);
CREATE INDEX IF NOT EXISTS withdrawal_requests_reviewed_by_idx ON public.withdrawal_requests(reviewed_by);
COMMIT;
