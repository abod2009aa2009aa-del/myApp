-- Applied 2026-10-13. Supabase default privileges had granted write privileges on the new view.
revoke all on public.wallet_balances from anon, authenticated;
grant select on public.wallet_balances to authenticated;
