-- A direct INSERT could bypass request_withdrawal()'s server-side settings,
-- balance and open-request checks. Keep requests on the guarded RPC path.
REVOKE INSERT ON TABLE public.withdrawal_requests FROM anon, authenticated;
COMMENT ON TABLE public.withdrawal_requests IS
  'Direct client INSERT is intentionally revoked; requests must use the guarded request_withdrawal RPC.';
