-- Only trusted platform admins can inspect provider payment events.
create policy payment_events_admin_select
on public.payment_events
for select to authenticated
using (public.is_platform_admin());
