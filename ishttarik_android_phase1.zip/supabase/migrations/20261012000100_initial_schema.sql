-- Ishttarik initial schema
-- Safe, additive migration: no DROP/TRUNCATE, no payment provider, no seed earnings.
-- Apply only after reviewing in the Supabase SQL Editor or via Supabase CLI.

begin;

create schema if not exists extensions;

-- Admin is controlled only through trusted app_metadata set by a server/admin process.
-- Never use user_metadata for authorization: users can edit it themselves.
create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'platform_role') = 'admin', false);
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 80),
  avatar_url text check (avatar_url is null or char_length(avatar_url) <= 2048),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 160),
  description text not null default '' check (char_length(description) <= 4000),
  advertiser_name text not null default '' check (char_length(advertiser_name) <= 160),
  status text not null default 'draft' check (status in ('draft','active','paused','ended','archived')),
  destination_url text check (destination_url is null or destination_url ~ '^https://'),
  starts_at timestamptz,
  ends_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);

create table if not exists public.ad_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  campaign_id uuid not null references public.ad_campaigns(id) on delete restrict,
  status text not null default 'started' check (status in ('started','verified','rejected','expired')),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  verification_reference text unique,
  created_at timestamptz not null default now(),
  check ((status = 'started' and completed_at is null) or status <> 'started')
);

create table if not exists public.verified_ad_events (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.ad_sessions(id) on delete restrict,
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (char_length(provider) between 1 and 80),
  provider_event_id text,
  event_type text not null check (event_type in ('impression','completion','invalid','reversal')),
  verified boolean not null default false,
  occurred_at timestamptz,
  received_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb,
  unique (provider, provider_event_id)
);

create table if not exists public.revenue_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  session_id uuid references public.ad_sessions(id) on delete restrict,
  gross_amount numeric(14,2) not null check (gross_amount >= 0),
  platform_amount numeric(14,2) not null check (platform_amount >= 0),
  user_amount numeric(14,2) not null check (user_amount >= 0),
  currency text not null default 'IQD' check (currency ~ '^[A-Z]{3}$'),
  status text not null default 'pending' check (status in ('pending','confirmed','reversed','void')),
  source_reference text unique,
  created_at timestamptz not null default now(),
  confirmed_at timestamptz,
  check (abs(gross_amount - platform_amount - user_amount) <= 0.02)
);

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  transaction_type text not null check (transaction_type in ('earning','withdrawal_hold','withdrawal_release','withdrawal_paid','adjustment','reversal')),
  amount numeric(14,2) not null check (amount > 0),
  currency text not null default 'IQD' check (currency ~ '^[A-Z]{3}$'),
  status text not null default 'pending' check (status in ('pending','posted','reversed','void')),
  reference_type text,
  reference_id uuid,
  idempotency_key text unique,
  note text check (note is null or char_length(note) <= 500),
  created_at timestamptz not null default now(),
  posted_at timestamptz
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  requested_amount numeric(14,2) not null check (requested_amount > 0),
  currency text not null default 'IQD' check (currency ~ '^[A-Z]{3}$'),
  status text not null default 'pending' check (status in ('pending','under_review','approved','rejected','cancelled','paid')),
  user_note text check (user_note is null or char_length(user_note) <= 500),
  reviewer_note text check (reviewer_note is null or char_length(reviewer_note) <= 1000),
  reviewed_by uuid references auth.users(id) on delete set null,
  requested_at timestamptz not null default now(),
  reviewed_at timestamptz,
  paid_at timestamptz
);

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (char_length(provider) between 1 and 80),
  provider_event_id text,
  event_type text not null check (char_length(event_type) between 1 and 100),
  status text not null default 'received' check (status in ('received','verified','ignored','failed')),
  payload_hash text,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider, provider_event_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 160),
  body text not null default '' check (char_length(body) <= 2000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) between 1 and 180),
  message text not null check (char_length(message) between 1 and 5000),
  status text not null default 'open' check (status in ('open','in_progress','answered','closed')),
  staff_reply text check (staff_reply is null or char_length(staff_reply) <= 5000),
  assigned_to uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null check (char_length(action) between 1 and 120),
  entity_type text not null check (char_length(entity_type) between 1 and 120),
  entity_id text check (entity_id is null or char_length(entity_id) <= 200),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists ad_campaigns_status_dates_idx on public.ad_campaigns(status, starts_at, ends_at);
create index if not exists ad_sessions_user_created_idx on public.ad_sessions(user_id, created_at desc);
create index if not exists ad_sessions_campaign_idx on public.ad_sessions(campaign_id);
create index if not exists verified_ad_events_user_received_idx on public.verified_ad_events(user_id, received_at desc);
create index if not exists revenue_records_user_created_idx on public.revenue_records(user_id, created_at desc);
create index if not exists wallet_transactions_user_created_idx on public.wallet_transactions(user_id, created_at desc);
create index if not exists withdrawal_requests_user_requested_idx on public.withdrawal_requests(user_id, requested_at desc);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists support_tickets_user_created_idx on public.support_tickets(user_id, created_at desc);
create index if not exists audit_logs_created_idx on public.audit_logs(created_at desc);

-- Create a profile on signup. The function is intentionally narrow and uses a fixed search_path.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- updated_at helper; no client write access is granted to protected financial/status tables.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();
create trigger campaigns_set_updated_at before update on public.ad_campaigns
for each row execute function public.set_updated_at();
create trigger tickets_set_updated_at before update on public.support_tickets
for each row execute function public.set_updated_at();

-- Enable RLS on every application table. No policy means denied to anon/authenticated by default.
alter table public.profiles enable row level security;
alter table public.ad_campaigns enable row level security;
alter table public.ad_sessions enable row level security;
alter table public.verified_ad_events enable row level security;
alter table public.revenue_records enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.payment_events enable row level security;
alter table public.notifications enable row level security;
alter table public.support_tickets enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: users can read/update only their own basic profile fields.
create policy profiles_select_own on public.profiles for select to authenticated
using (id = (select auth.uid()) or public.is_platform_admin());
create policy profiles_update_own on public.profiles for update to authenticated
using (id = (select auth.uid()))
with check (id = (select auth.uid()));

-- Campaigns: users can see active campaigns; admins manage campaign records.
create policy campaigns_select_active on public.ad_campaigns for select to authenticated
using (status = 'active' or public.is_platform_admin());
create policy campaigns_admin_insert on public.ad_campaigns for insert to authenticated
with check (public.is_platform_admin());
create policy campaigns_admin_update on public.ad_campaigns for update to authenticated
using (public.is_platform_admin()) with check (public.is_platform_admin());
create policy campaigns_admin_delete on public.ad_campaigns for delete to authenticated
using (public.is_platform_admin());

-- A user may start a session for themselves, but cannot mark it verified or edit its status.
create policy ad_sessions_select_own on public.ad_sessions for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());
create policy ad_sessions_insert_own_started on public.ad_sessions for insert to authenticated
with check (
  user_id = (select auth.uid())
  and status = 'started'
  and completed_at is null
  and verification_reference is null
  and exists (
    select 1 from public.ad_campaigns c
    where c.id = campaign_id and c.status = 'active'
  )
);

-- Verified events, revenue, wallet transactions and payment events have no client write policies.
-- Service-role/server functions must validate provider callbacks and perform ledger writes.
create policy verified_ad_events_select_own on public.verified_ad_events for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());
create policy revenue_records_select_own on public.revenue_records for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());
create policy wallet_transactions_select_own on public.wallet_transactions for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());

-- Users may submit a pending withdrawal request, but cannot approve, edit, or mark it paid.
-- This is only an internal request record; no payment is initiated by this schema.
create policy withdrawal_requests_select_own on public.withdrawal_requests for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());
create policy withdrawal_requests_insert_pending_own on public.withdrawal_requests for insert to authenticated
with check (
  user_id = (select auth.uid())
  and status = 'pending'
  and reviewed_by is null
  and reviewed_at is null
  and paid_at is null
);

create policy notifications_select_own on public.notifications for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());
create policy notifications_mark_read_own on public.notifications for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy support_tickets_select_own on public.support_tickets for select to authenticated
using (user_id = (select auth.uid()) or public.is_platform_admin());
create policy support_tickets_insert_own on public.support_tickets for insert to authenticated
with check (user_id = (select auth.uid()) and status = 'open' and staff_reply is null and assigned_to is null);
create policy support_tickets_admin_update on public.support_tickets for update to authenticated
using (public.is_platform_admin()) with check (public.is_platform_admin());

create policy audit_logs_admin_select on public.audit_logs for select to authenticated
using (public.is_platform_admin());

-- Explicit table privileges complement RLS. No anonymous access and no client writes to ledgers.
revoke all on table public.profiles, public.ad_campaigns, public.ad_sessions,
  public.verified_ad_events, public.revenue_records, public.wallet_transactions,
  public.withdrawal_requests, public.payment_events, public.notifications,
  public.support_tickets, public.audit_logs from anon;

-- Clear any broad default grants before granting only the intended client operations.
revoke all on table public.profiles, public.ad_campaigns, public.ad_sessions,
  public.verified_ad_events, public.revenue_records, public.wallet_transactions,
  public.withdrawal_requests, public.payment_events, public.notifications,
  public.support_tickets, public.audit_logs from authenticated;

grant select on table public.profiles to authenticated;
revoke update on table public.profiles from authenticated;
grant update (display_name, avatar_url) on table public.profiles to authenticated;
grant select, insert, update, delete on table public.ad_campaigns to authenticated;
grant select on table public.ad_sessions to authenticated;
revoke insert on table public.ad_sessions from authenticated;
grant insert (user_id, campaign_id) on table public.ad_sessions to authenticated;
grant select on table public.verified_ad_events, public.revenue_records, public.wallet_transactions to authenticated;
grant select on table public.withdrawal_requests to authenticated;
revoke insert on table public.withdrawal_requests from authenticated;
grant insert (user_id, requested_amount, currency, user_note) on table public.withdrawal_requests to authenticated;
grant select on table public.notifications to authenticated;
revoke update on table public.notifications from authenticated;
grant update (read_at) on table public.notifications to authenticated;
grant select, update on table public.support_tickets to authenticated;
revoke insert on table public.support_tickets from authenticated;
grant insert (user_id, subject, message) on table public.support_tickets to authenticated;
grant select on table public.audit_logs to authenticated;

-- Keep internal payment event table inaccessible to anon/authenticated; service_role bypasses RLS.
revoke all on table public.payment_events from authenticated;
revoke all on table public.audit_logs from anon;

-- Function execution permissions: safe admin-check helper is callable but only reads JWT claims.
revoke all on function public.is_platform_admin() from public;
grant execute on function public.is_platform_admin() to authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.set_updated_at() from public, anon, authenticated;

commit;
