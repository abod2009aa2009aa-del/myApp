-- Server-side ledger rules. ADDITIVE (no drops). APPLIED to the project on 2026-10-13 via apply_migration
-- (which wraps it in a transaction) and verified by 36 rolled-back checks (see STATUS.md).

create table if not exists public.platform_settings (
  id boolean primary key default true check (id),
  user_share_bps integer not null default 6500 check (user_share_bps between 0 and 10000),
  min_withdrawal numeric(14,2) not null default 0 check (min_withdrawal >= 0),
  withdrawals_enabled boolean not null default false,
  revenue_enabled boolean not null default false,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
insert into public.platform_settings (id) values (true) on conflict (id) do nothing;
alter table public.platform_settings enable row level security;
create policy platform_settings_admin_select on public.platform_settings for select to authenticated
using (public.is_platform_admin());
revoke all on table public.platform_settings from anon, authenticated;
grant select on table public.platform_settings to authenticated;
create index if not exists platform_settings_updated_by_idx on public.platform_settings(updated_by);

alter table public.revenue_records add column if not exists provider text check (provider is null or char_length(provider) <= 80);
alter table public.revenue_records add column if not exists user_share_bps integer check (user_share_bps between 0 and 10000);
alter table public.revenue_records add column if not exists reversed_at timestamptz;
alter table public.revenue_records add column if not exists reversal_reason text check (reversal_reason is null or char_length(reversal_reason) <= 500);

-- Append-only ledger: no deletes; only the status transitions below are allowed.
create or replace function public.ledger_immutable()
returns trigger language plpgsql set search_path = '' as $$
begin
  if tg_op = 'DELETE' then
    raise exception 'ledger rows cannot be deleted' using errcode = '42501';
  end if;
  if tg_table_name = 'wallet_transactions' then
    if not (old.status = 'pending' and new.status in ('posted','void'))
       or (to_jsonb(new) - 'status' - 'posted_at') is distinct from (to_jsonb(old) - 'status' - 'posted_at') then
      raise exception 'wallet_transactions is append-only' using errcode = '42501';
    end if;
  else
    if not ((old.status = 'pending' and new.status in ('confirmed','void')) or (old.status = 'confirmed' and new.status = 'reversed'))
       or (to_jsonb(new) - 'status' - 'confirmed_at' - 'reversed_at' - 'reversal_reason')
          is distinct from (to_jsonb(old) - 'status' - 'confirmed_at' - 'reversed_at' - 'reversal_reason') then
      raise exception 'revenue_records is append-only' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
revoke all on function public.ledger_immutable() from public, anon, authenticated;
drop trigger if exists wallet_transactions_immutable on public.wallet_transactions;
create trigger wallet_transactions_immutable before update or delete on public.wallet_transactions
for each row execute function public.ledger_immutable();
drop trigger if exists revenue_records_immutable on public.revenue_records;
create trigger revenue_records_immutable before update or delete on public.revenue_records
for each row execute function public.ledger_immutable();

-- Balances computed in the database (respects RLS through security_invoker).
create or replace view public.wallet_balances with (security_invoker = true) as
select user_id, currency,
  coalesce(sum(case when status = 'posted' then case transaction_type
    when 'earning' then amount when 'adjustment' then amount when 'withdrawal_release' then amount
    when 'withdrawal_hold' then -amount when 'reversal' then -amount else 0 end else 0 end), 0)::numeric(14,2) as available,
  coalesce(sum(case when status = 'pending' and transaction_type in ('earning','adjustment') then amount else 0 end), 0)::numeric(14,2) as pending,
  coalesce(sum(case when status = 'posted' then case transaction_type
    when 'withdrawal_hold' then amount when 'withdrawal_release' then -amount when 'withdrawal_paid' then -amount else 0 end else 0 end), 0)::numeric(14,2) as held
from public.wallet_transactions group by user_id, currency;
revoke all on public.wallet_balances from anon;
grant select on public.wallet_balances to authenticated;

-- Settlement: callable ONLY by service_role (a trusted server). Idempotent on source_reference.
create or replace function public.settle_revenue(p_source_reference text, p_user_id uuid, p_gross numeric,
  p_currency text, p_provider text, p_session_id uuid default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_bps integer; v_on boolean; v_user numeric(14,2); v_platform numeric(14,2); v_id uuid; v_ex public.revenue_records;
begin
  if p_source_reference is null or char_length(p_source_reference) not between 1 and 200 then raise exception 'invalid_source_reference'; end if;
  if p_gross is null or p_gross < 0 or p_gross <> round(p_gross, 2) then raise exception 'invalid_amount'; end if;
  if p_currency is null or p_currency !~ '^[A-Z]{3}$' then raise exception 'invalid_currency'; end if;
  select user_share_bps, revenue_enabled into v_bps, v_on from public.platform_settings where id;
  if not v_on then raise exception 'revenue_disabled'; end if;
  v_user := trunc(p_gross * v_bps / 10000.0, 2); v_platform := p_gross - v_user;
  insert into public.revenue_records (user_id, session_id, gross_amount, platform_amount, user_amount, currency, status,
                                      source_reference, provider, user_share_bps, confirmed_at)
  values (p_user_id, p_session_id, p_gross, v_platform, v_user, p_currency, 'confirmed', p_source_reference, p_provider, v_bps, now())
  on conflict (source_reference) do nothing returning id into v_id;
  if v_id is null then
    select * into v_ex from public.revenue_records where source_reference = p_source_reference;
    if v_ex.user_id <> p_user_id or v_ex.gross_amount <> p_gross or v_ex.currency <> p_currency then raise exception 'source_reference_conflict'; end if;
    return v_ex.id;
  end if;
  if v_user > 0 then
    insert into public.wallet_transactions (user_id, transaction_type, amount, currency, status, reference_type, reference_id, idempotency_key, note, posted_at)
    values (p_user_id, 'earning', v_user, p_currency, 'posted', 'revenue_record', v_id, 'earning:' || p_source_reference, 'revenue share', now());
  end if;
  return v_id;
end $$;

create or replace function public.reverse_revenue(p_source_reference text, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v public.revenue_records;
begin
  select * into v from public.revenue_records where source_reference = p_source_reference for update;
  if not found then raise exception 'not_found'; end if;
  if v.status = 'reversed' then return v.id; end if;
  if v.status <> 'confirmed' then raise exception 'not_reversible'; end if;
  update public.revenue_records set status = 'reversed', reversed_at = now(), reversal_reason = left(coalesce(p_reason, ''), 500) where id = v.id;
  if v.user_amount > 0 then
    insert into public.wallet_transactions (user_id, transaction_type, amount, currency, status, reference_type, reference_id, idempotency_key, note, posted_at)
    values (v.user_id, 'reversal', v.user_amount, v.currency, 'posted', 'revenue_record', v.id, 'reversal:' || p_source_reference, left(coalesce(p_reason, ''), 500), now())
    on conflict (idempotency_key) do nothing;
  end if;
  return v.id;
end $$;

-- Withdrawal request: server-side balance check, one open request per user, serialized per user.
-- Stays disabled (platform_settings.withdrawals_enabled = false) until a payment provider is approved.
create or replace function public.request_withdrawal(p_amount numeric, p_currency text, p_note text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_uid uuid := auth.uid(); v_on boolean; v_min numeric; v_avail numeric; v_id uuid;
begin
  if v_uid is null then raise exception 'not_authenticated' using errcode = '42501'; end if;
  select withdrawals_enabled, min_withdrawal into v_on, v_min from public.platform_settings where id;
  if not v_on then raise exception 'withdrawals_disabled'; end if;
  perform pg_advisory_xact_lock(hashtextextended(v_uid::text, 0));
  if p_amount is null or p_amount <= 0 or p_amount <> round(p_amount, 2) then raise exception 'invalid_amount'; end if;
  if p_amount < v_min then raise exception 'below_minimum'; end if;
  if exists (select 1 from public.withdrawal_requests where user_id = v_uid and status in ('pending','under_review','approved')) then raise exception 'open_request_exists'; end if;
  select coalesce(sum(case transaction_type when 'earning' then amount when 'adjustment' then amount when 'withdrawal_release' then amount
                      when 'withdrawal_hold' then -amount when 'reversal' then -amount else 0 end), 0)
    into v_avail from public.wallet_transactions where user_id = v_uid and currency = p_currency and status = 'posted';
  if v_avail < p_amount then raise exception 'insufficient_balance'; end if;
  insert into public.withdrawal_requests (user_id, requested_amount, currency, user_note) values (v_uid, p_amount, p_currency, left(p_note, 500)) returning id into v_id;
  insert into public.wallet_transactions (user_id, transaction_type, amount, currency, status, reference_type, reference_id, idempotency_key, posted_at)
  values (v_uid, 'withdrawal_hold', p_amount, p_currency, 'posted', 'withdrawal_request', v_id, 'hold:' || v_id, now());
  return v_id;
end $$;

-- Admin may tune the split / minimum (never the enable flags, which only the project owner flips in SQL). Audited.
create or replace function public.admin_update_settings(p_user_share_bps integer default null, p_min_withdrawal numeric default null)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_platform_admin() then raise exception 'forbidden' using errcode = '42501'; end if;
  update public.platform_settings set user_share_bps = coalesce(p_user_share_bps, user_share_bps),
    min_withdrawal = coalesce(p_min_withdrawal, min_withdrawal), updated_by = auth.uid(), updated_at = now() where id;
  insert into public.audit_logs (actor_user_id, action, entity_type, entity_id, details)
  values (auth.uid(), 'update_settings', 'platform_settings', 'singleton', jsonb_build_object('user_share_bps', p_user_share_bps, 'min_withdrawal', p_min_withdrawal));
end $$;

revoke all on function public.settle_revenue(text, uuid, numeric, text, text, uuid) from public, anon, authenticated;
revoke all on function public.reverse_revenue(text, text) from public, anon, authenticated;
grant execute on function public.settle_revenue(text, uuid, numeric, text, text, uuid) to service_role;
grant execute on function public.reverse_revenue(text, text) to service_role;
revoke all on function public.request_withdrawal(numeric, text, text) from public, anon;
grant execute on function public.request_withdrawal(numeric, text, text) to authenticated;
revoke all on function public.admin_update_settings(integer, numeric) from public, anon;
grant execute on function public.admin_update_settings(integer, numeric) to authenticated;

-- Close the direct-insert path: withdrawals go only through request_withdrawal().
revoke insert on table public.withdrawal_requests from authenticated;
