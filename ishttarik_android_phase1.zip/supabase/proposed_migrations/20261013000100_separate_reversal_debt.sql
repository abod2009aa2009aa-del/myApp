-- Phase 7: separate reversal debt from spendable balance.
-- This migration changes schema/functions only; it creates no test users or financial rows.
-- Revenue and withdrawals remain disabled by default and are not enabled here.

create table if not exists public.wallet_debt_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  currency text not null check (currency ~ '^[A-Z]{3}$'),
  debt_change numeric(14,2) not null check (debt_change <> 0 and debt_change = round(debt_change, 2)),
  source_type text not null check (source_type in ('reversal_debt', 'earning_offset', 'admin_adjustment')),
  source_reference text not null check (char_length(source_reference) between 1 and 200),
  idempotency_key text not null unique,
  note text check (note is null or char_length(note) <= 500),
  created_at timestamptz not null default now()
);

alter table public.wallet_debt_transactions enable row level security;
revoke all on public.wallet_debt_transactions from public, anon, authenticated;
grant select on public.wallet_debt_transactions to authenticated;
create policy wallet_debt_transactions_select_own on public.wallet_debt_transactions
  for select to authenticated using (user_id = auth.uid());

create or replace function public.wallet_debt_immutable()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception 'wallet debt ledger is append-only' using errcode = '42501';
end $$;
revoke all on function public.wallet_debt_immutable() from public, anon, authenticated;
create trigger wallet_debt_transactions_immutable
  before update or delete on public.wallet_debt_transactions
  for each row execute function public.wallet_debt_immutable();

create or replace view public.wallet_balances with (security_invoker = true) as
select b.user_id, b.currency,
  greatest(b.raw_available, 0)::numeric(14,2) as available,
  b.pending::numeric(14,2) as pending,
  b.held::numeric(14,2) as held,
  greatest(coalesce(d.debt, 0), 0)::numeric(14,2) as debt
from (
  select user_id, currency,
    coalesce(sum(case when status = 'posted' then case transaction_type
      when 'earning' then amount when 'adjustment' then amount when 'withdrawal_release' then amount
      when 'withdrawal_hold' then -amount when 'reversal' then -amount else 0 end else 0 end), 0) as raw_available,
    coalesce(sum(case when status = 'pending' and transaction_type in ('earning','adjustment') then amount else 0 end), 0) as pending,
    coalesce(sum(case when status = 'posted' then case transaction_type
      when 'withdrawal_hold' then amount when 'withdrawal_release' then -amount when 'withdrawal_paid' then -amount else 0 end else 0 end), 0) as held
  from public.wallet_transactions group by user_id, currency
) b
left join (
  select user_id, currency, sum(debt_change) as debt
  from public.wallet_debt_transactions group by user_id, currency
) d using (user_id, currency);
revoke all on public.wallet_balances from anon, authenticated;
grant select on public.wallet_balances to authenticated;

create or replace function public.settle_revenue(p_source_reference text, p_user_id uuid, p_gross numeric,
  p_currency text, p_provider text, p_session_id uuid default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_bps integer; v_on boolean; v_user numeric(14,2); v_platform numeric(14,2);
  v_net numeric(14,2); v_debt numeric(14,2); v_offset numeric(14,2); v_id uuid; v_ex public.revenue_records;
begin
  if p_source_reference is null or char_length(p_source_reference) not between 1 and 200 then raise exception 'invalid_source_reference'; end if;
  if p_gross is null or p_gross < 0 or p_gross <> round(p_gross, 2) then raise exception 'invalid_amount'; end if;
  if p_currency is null or p_currency !~ '^[A-Z]{3}$' then raise exception 'invalid_currency'; end if;
  if p_user_id is null then raise exception 'invalid_user'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_user_id::text || ':' || p_currency, 0));
  select user_share_bps, revenue_enabled into v_bps, v_on from public.platform_settings where id;
  if not v_on then raise exception 'revenue_disabled'; end if;
  v_user := trunc(p_gross * v_bps / 10000.0, 2); v_platform := p_gross - v_user;
  insert into public.revenue_records (user_id, session_id, gross_amount, platform_amount, user_amount, currency, status,
                                      source_reference, provider, user_share_bps, confirmed_at)
  values (p_user_id, p_session_id, p_gross, v_platform, v_user, p_currency, 'confirmed', p_source_reference, p_provider, v_bps, now())
  on conflict (source_reference) do nothing returning id into v_id;
  if v_id is null then
    select * into v_ex from public.revenue_records where source_reference = p_source_reference;
    if v_ex.user_id <> p_user_id or v_ex.gross_amount <> p_gross or v_ex.currency <> p_currency then raise exception 'source_reference_conflict'; end if;
    return v_ex.id;
  end if;
  select greatest(coalesce(sum(debt_change),0),0) into v_debt
    from public.wallet_debt_transactions where user_id=p_user_id and currency=p_currency;
  v_offset := least(v_user, v_debt);
  v_net := v_user - v_offset;
  if v_offset > 0 then
    insert into public.wallet_debt_transactions (user_id,currency,debt_change,source_type,source_reference,idempotency_key,note)
    values (p_user_id,p_currency,-v_offset,'earning_offset',p_source_reference,'debt-offset:'||p_source_reference,'Automatically offset reversal debt')
    on conflict (idempotency_key) do nothing;
  end if;
  if v_net > 0 then
    insert into public.wallet_transactions (user_id, transaction_type, amount, currency, status, reference_type, reference_id, idempotency_key, note, posted_at)
    values (p_user_id, 'earning', v_net, p_currency, 'posted', 'revenue_record', v_id, 'earning:' || p_source_reference, 'net revenue share after debt offset', now());
  end if;
  return v_id;
end $$;

create or replace function public.reverse_revenue(p_source_reference text, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v public.revenue_records; v_available numeric(14,2); v_reversal numeric(14,2); v_debt numeric(14,2);
begin
  select * into v from public.revenue_records where source_reference = p_source_reference for update;
  if not found then raise exception 'not_found'; end if;
  if v.status = 'reversed' then return v.id; end if;
  if v.status <> 'confirmed' then raise exception 'not_reversible'; end if;
  perform pg_advisory_xact_lock(hashtextextended(v.user_id::text || ':' || v.currency, 0));
  select coalesce(sum(case transaction_type when 'earning' then amount when 'adjustment' then amount when 'withdrawal_release' then amount
                      when 'withdrawal_hold' then -amount when 'reversal' then -amount else 0 end), 0)
    into v_available from public.wallet_transactions where user_id=v.user_id and currency=v.currency and status='posted';
  v_reversal := least(greatest(v_available,0),v.user_amount);
  v_debt := v.user_amount - v_reversal;
  update public.revenue_records set status = 'reversed', reversed_at = now(), reversal_reason = left(coalesce(p_reason, ''), 500) where id = v.id;
  if v_reversal > 0 then
    insert into public.wallet_transactions (user_id, transaction_type, amount, currency, status, reference_type, reference_id, idempotency_key, note, posted_at)
    values (v.user_id, 'reversal', v_reversal, v.currency, 'posted', 'revenue_record', v.id, 'reversal:' || p_source_reference, left(coalesce(p_reason, ''), 500), now())
    on conflict (idempotency_key) do nothing;
  end if;
  if v_debt > 0 then
    insert into public.wallet_debt_transactions (user_id,currency,debt_change,source_type,source_reference,idempotency_key,note)
    values (v.user_id,v.currency,v_debt,'reversal_debt',p_source_reference,'reversal-debt:'||p_source_reference,left(coalesce(p_reason,''),500))
    on conflict (idempotency_key) do nothing;
  end if;
  return v.id;
end $$;

create or replace function public.request_withdrawal(p_amount numeric, p_currency text, p_note text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_uid uuid := auth.uid(); v_on boolean; v_min numeric; v_avail numeric; v_debt numeric; v_id uuid;
begin
  if v_uid is null then raise exception 'not_authenticated' using errcode = '42501'; end if;
  if p_currency is null or p_currency !~ '^[A-Z]{3}$' then raise exception 'invalid_currency'; end if;
  select withdrawals_enabled, min_withdrawal into v_on, v_min from public.platform_settings where id;
  if not v_on then raise exception 'withdrawals_disabled'; end if;
  perform pg_advisory_xact_lock(hashtextextended(v_uid::text || ':' || p_currency, 0));
  if p_amount is null or p_amount <= 0 or p_amount <> round(p_amount, 2) then raise exception 'invalid_amount'; end if;
  if p_amount < v_min then raise exception 'below_minimum'; end if;
  select greatest(coalesce(sum(debt_change),0),0) into v_debt from public.wallet_debt_transactions where user_id=v_uid and currency=p_currency;
  if v_debt > 0 then raise exception 'outstanding_reversal_debt'; end if;
  if exists (select 1 from public.withdrawal_requests where user_id = v_uid and status in ('pending','under_review','approved')) then raise exception 'open_request_exists'; end if;
  select greatest(coalesce(sum(case transaction_type when 'earning' then amount when 'adjustment' then amount when 'withdrawal_release' then amount
                      when 'withdrawal_hold' then -amount when 'reversal' then -amount else 0 end), 0),0)
    into v_avail from public.wallet_transactions where user_id = v_uid and currency = p_currency and status = 'posted';
  if v_avail < p_amount then raise exception 'insufficient_balance'; end if;
  insert into public.withdrawal_requests (user_id, requested_amount, currency, user_note) values (v_uid, p_amount, p_currency, left(p_note, 500)) returning id into v_id;
  insert into public.wallet_transactions (user_id, transaction_type, amount, currency, status, reference_type, reference_id, idempotency_key, posted_at)
  values (v_uid, 'withdrawal_hold', p_amount, p_currency, 'posted', 'withdrawal_request', v_id, 'hold:' || v_id, now());
  return v_id;
end $$;

-- Keep the intended RPCs available only to authenticated users; their SECURITY DEFINER
-- context is required because clients cannot write the append-only financial tables.
revoke all on function public.settle_revenue(text, uuid, numeric, text, text, uuid) from public, anon, authenticated;
grant execute on function public.settle_revenue(text, uuid, numeric, text, text, uuid) to service_role;
revoke all on function public.reverse_revenue(text, text) from public, anon, authenticated;
grant execute on function public.reverse_revenue(text, text) to service_role;
revoke all on function public.request_withdrawal(numeric, text, text) from public, anon;
grant execute on function public.request_withdrawal(numeric, text, text) to authenticated;
revoke all on function public.admin_update_settings(integer, numeric) from public, anon;
grant execute on function public.admin_update_settings(integer, numeric) to authenticated;
