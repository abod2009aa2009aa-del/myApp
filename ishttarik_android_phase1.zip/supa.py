"""Minimal Supabase client (standard library only).

Security rules enforced here:
  * Only the PUBLIC key (anon / sb_publishable_*) is accepted. A service_role / sb_secret_* key
    is rejected at startup so it can never end up inside the web process by mistake.
  * Every data call carries the signed-in user's own JWT, so Postgres RLS decides what is visible.
  * Network failures raise SupaDown; callers must show an error, never a fake success.
"""
import base64, hashlib, json, os, threading, time
import urllib.error, urllib.parse, urllib.request

class SupaError(Exception):
    def __init__(self, status, code='', msg=''):
        super().__init__(f'{status} {code}'); self.status = status; self.code = code; self.msg = msg
class SupaDown(Exception):
    pass
class SupaConfigError(Exception):
    pass

def cfg():
    return os.environ.get('SUPABASE_URL', '').strip().rstrip('/'), os.environ.get('SUPABASE_ANON_KEY', '').strip()

def enabled():
    u, k = cfg(); return bool(u and k)

def validate_config():
    """Raise SupaConfigError for unsafe configuration. Returns (url, key)."""
    url, key = cfg()
    host = urllib.parse.urlparse(url).hostname or ''
    if not url.startswith('https://') and host not in ('127.0.0.1', 'localhost'):
        raise SupaConfigError('SUPABASE_URL must use https')
    if key.startswith('sb_secret_'):
        raise SupaConfigError('SUPABASE_ANON_KEY holds a secret key; use the publishable key only')
    parts = key.split('.')
    if len(parts) == 3:
        try:
            pad = parts[1] + '=' * (-len(parts[1]) % 4)
            role = json.loads(base64.urlsafe_b64decode(pad)).get('role')
        except Exception:
            role = None
        if role == 'service_role':
            raise SupaConfigError('SUPABASE_ANON_KEY holds a service_role key; refusing to start')
    return url, key

def _call(method, path, body=None, token=None, extra=None, timeout=8):
    url, key = cfg()
    h = {'apikey': key, 'Authorization': 'Bearer ' + (token or key), 'Accept': 'application/json'}
    data = None
    if body is not None:
        data = json.dumps(body).encode(); h['Content-Type'] = 'application/json'
    h.update(extra or {})
    req = urllib.request.Request(url + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read(); hdr = dict(r.headers); st = r.status
    except urllib.error.HTTPError as e:
        raw = e.read(); st = e.code; hdr = dict(e.headers)
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise SupaDown(type(e).__name__)
    try:
        js = json.loads(raw) if raw else None
    except ValueError:
        js = None
    if st >= 400:
        j = js if isinstance(js, dict) else {}
        raise SupaError(st, str(j.get('error_code') or j.get('code') or j.get('error') or ''), str(j.get('msg') or j.get('message') or j.get('error_description') or ''))
    return st, js, hdr

# ---- auth -----------------------------------------------------------------
def signup(email, password, redirect_to=None):
    path = '/auth/v1/signup' + ('?redirect_to=' + urllib.parse.quote(redirect_to, safe='') if redirect_to else '')
    return _call('POST', path, {'email': email, 'password': password})[1] or {}

def login(email, password):
    return _call('POST', '/auth/v1/token?grant_type=password', {'email': email, 'password': password})[1]

def refresh(refresh_token):
    return _call('POST', '/auth/v1/token?grant_type=refresh_token', {'refresh_token': refresh_token})[1]

_cache = {}; _lock = threading.Lock(); CACHE_TTL = 20
def _ck(t): return hashlib.sha256(t.encode()).hexdigest()
def get_user(token):
    """Ask Supabase to validate the access token. Cached for a few seconds only."""
    k = _ck(token); now = time.time()
    with _lock:
        hit = _cache.get(k)
        if hit and now - hit[0] < CACHE_TTL: return hit[1]
    u = _call('GET', '/auth/v1/user', token=token)[1]
    with _lock:
        if len(_cache) > 2000: _cache.clear()
        _cache[k] = (now, u)
    return u

def logout(token):
    """Attempt provider-side revocation; False means it could not be confirmed."""
    if not token: return True
    with _lock: _cache.pop(_ck(token), None)
    try:
        _call('POST', '/auth/v1/logout', token=token)
        return True
    except SupaError as e:
        # A provider-side 401/403 means this credential is already unusable.
        return e.status in (401, 403)
    except SupaDown:
        return False

def recover(email, redirect_to=None):
    path = '/auth/v1/recover' + ('?redirect_to=' + urllib.parse.quote(redirect_to, safe='') if redirect_to else '')
    _call('POST', path, {'email': email})

def update_password(token, password):
    _call('PUT', '/auth/v1/user', {'password': password}, token=token)

def health():
    try: _call('GET', '/auth/v1/health', timeout=4); return True
    except (SupaDown, SupaError): return False

# ---- data (PostgREST, always as the signed-in user) -------------------------
def rest(method, table, token, params=None, body=None, count=False, prefer=None):
    q = ('?' + urllib.parse.urlencode(params)) if params else ''
    pf = []
    if count: pf.append('count=exact')
    if prefer: pf.append(prefer)
    st, js, hdr = _call(method, '/rest/v1/' + table + q, body=body, token=token, extra={'Prefer': ','.join(pf)} if pf else None)
    return js, hdr

def total_from(hdr):
    cr = {k.lower(): v for k, v in hdr.items()}.get('content-range', '')
    try: return int(cr.rsplit('/', 1)[1])
    except Exception: return None

# ---- Arabic messages (never echo raw provider text) -------------------------
def ar_error(e):
    if isinstance(e, SupaDown): return 'تعذر الاتصال بخدمة المصادقة. لم يتم تنفيذ أي إجراء، حاول لاحقاً.'
    c = (getattr(e, 'code', '') or '').lower(); s = getattr(e, 'status', 0); m = (getattr(e, 'msg', '') or '').lower()
    if c == 'invalid_credentials' or 'invalid login' in m: return 'بيانات الدخول غير صحيحة.'
    if c == 'email_not_confirmed': return 'أكّد بريدك الإلكتروني أولاً ثم سجّل الدخول.'
    if c in ('weak_password',): return 'كلمة المرور ضعيفة. استخدم 10 أحرف أو أكثر مع تنويع.'
    if c in ('user_already_exists', 'email_exists'): return 'تعذر إنشاء الحساب بهذه البيانات.'
    if c == 'signup_disabled': return 'التسجيل غير متاح حالياً.'
    if s == 429 or 'rate_limit' in c: return 'محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.'
    if s in (400, 422): return 'تحقق من البيانات المدخلة وأعد المحاولة.'
    return 'تعذر إكمال الطلب. حاول لاحقاً.'
