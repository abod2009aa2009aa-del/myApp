"""HTML bodies for pages backed by Supabase. Every query runs with the user's own JWT (RLS applies).
If a query fails we say so; we never fall back to invented numbers."""
import html, re
import supa
E = html.escape
ERR = '<div class="notice error">تعذر قراءة البيانات من الخادم. لم يتم عرض أي أرقام افتراضية.</div>'
EMPTY = '<div class="card">لا توجد بيانات بعد.</div>'
STATE = {'pending': 'قيد المراجعة', 'under_review': 'قيد المراجعة', 'approved': 'مقبول', 'rejected': 'مرفوض', 'cancelled': 'ملغى', 'paid': 'مكتمل',
         'open': 'مفتوحة', 'in_progress': 'قيد المعالجة', 'answered': 'تمت الإجابة', 'closed': 'مغلقة', 'posted': 'مسجّلة', 'reversed': 'معكوسة', 'void': 'ملغاة'}
TYPES = {'earning': 'ربح مؤكد', 'withdrawal_hold': 'حجز للسحب', 'withdrawal_release': 'فك حجز', 'withdrawal_paid': 'سحب مدفوع', 'adjustment': 'تعديل', 'reversal': 'عكس قيد'}
CTRL = re.compile(r'[\x00-\x08\x0b-\x1f\x7f]')

def clean(s, n):
    return CTRL.sub('', s or '').strip()[:n]

def get(table, u, **params):
    try: return supa.rest('GET', table, u['token'], params)[0] or []
    except (supa.SupaError, supa.SupaDown): return None

def profile(u):
    r = get('profiles', u, select='display_name', id='eq.' + u['id'])
    if r is None: return ERR
    name = r[0]['display_name'] if r else ''
    return (f'<div class="card"><p>البريد: <b>{E(u["email"])}</b></p><p>الدور: {E(u["role"])}</p></div>'
            f'<form class="card" method="post" action="/profile"><label>الاسم المعروض<input name="display_name" maxlength="80" value="{E(name)}"></label>'
            '<button class="btn primary">حفظ</button></form>')

def wallet(u):
    bal = get('wallet_balances', u, select='currency,available,pending,held', user_id='eq.' + u['id'])
    tx = get('wallet_transactions', u, select='transaction_type,amount,currency,status,created_at', order='created_at.desc', limit='50')
    if bal is None or tx is None: return ERR
    if not bal and not tx:
        return '<div class="card">لا توجد معاملات مالية مسجلة بعد. الأرصدة تظهر فقط بعد تأكيد إيراد حقيقي.</div>'
    cards = ''.join(f'<div class="grid three"><article class="card"><h3>المتاح ({E(b["currency"])})</h3><p><b>{E(str(b["available"]))}</b></p></article>'
                    f'<article class="card"><h3>المعلّق</h3><p>{E(str(b["pending"]))}</p></article><article class="card"><h3>المحجوز للسحب</h3><p>{E(str(b["held"]))}</p></article></div>' for b in bal)
    rows = ''.join(f'<tr><td>{E(str(t["created_at"])[:10])}</td><td>{E(TYPES.get(t["transaction_type"], t["transaction_type"]))}</td><td dir="ltr">{E(str(t["amount"]))} {E(t["currency"])}</td><td>{E(STATE.get(t["status"], t["status"]))}</td></tr>' for t in tx)
    return cards + f'<div class="card"><h3>آخر المعاملات</h3><table><tr><th>التاريخ</th><th>النوع</th><th>المبلغ</th><th>الحالة</th></tr>{rows}</table></div>'

def withdrawals(u):
    r = get('withdrawal_requests', u, select='requested_amount,currency,status,reviewer_note,requested_at', order='requested_at.desc', limit='50')
    if r is None: return ERR
    note = '<div class="notice warn">طلبات السحب معطّلة حتى ربط مزود دفع مناسب واختباره وموافقة صريحة. لا ترسل معلومات مالية حساسة هنا.</div>'
    if not r: return note + EMPTY
    rows = ''.join(f'<tr><td>{E(str(x["requested_at"])[:10])}</td><td dir="ltr">{E(str(x["requested_amount"]))} {E(x["currency"])}</td><td>{E(STATE.get(x["status"], x["status"]))}</td><td>{E(x.get("reviewer_note") or "")}</td></tr>' for x in r)
    return note + f'<div class="card"><table><tr><th>التاريخ</th><th>المبلغ</th><th>الحالة</th><th>ملاحظة</th></tr>{rows}</table></div>'

def notifications(u):
    r = get('notifications', u, select='title,body,created_at,read_at', order='created_at.desc', limit='50')
    if r is None: return ERR
    if not r: return '<div class="card">لا توجد إشعارات حالياً.</div>'
    return ''.join(f'<div class="card"><b>{E(x["title"])}</b><p>{E(x["body"])}</p><small class="muted">{E(str(x["created_at"])[:10])}</small></div>' for x in r)

def support(u):
    r = get('support_tickets', u, select='subject,status,staff_reply,created_at', order='created_at.desc', limit='50')
    if r is None: return ERR
    form = ('<form class="card" method="post" action="/support"><label>الموضوع<input name="subject" maxlength="180" required></label>'
            '<label>الرسالة<textarea name="message" maxlength="5000" rows="5" required></textarea></label><button class="btn primary">إرسال</button></form>')
    items = ''.join(f'<div class="card"><b>{E(x["subject"])}</b> <span class="status">{E(STATE.get(x["status"], x["status"]))}</span>'
                    + (f'<p>رد الدعم: {E(x["staff_reply"])}</p>' if x.get('staff_reply') else '') + '</div>' for x in r)
    return form + (items or '<div class="card">لا توجد تذاكر بعد.</div>')

ADMIN_TABLES = [('profiles', 'الحسابات'), ('ad_campaigns', 'الحملات'), ('verified_ad_events', 'أحداث مُتحقَّق منها'),
                ('revenue_records', 'سجلات الإيراد'), ('withdrawal_requests', 'طلبات السحب'), ('support_tickets', 'تذاكر الدعم')]
def admin(u):
    cells = []
    for t, label in ADMIN_TABLES:
        try:
            _, h = supa.rest('GET', t, u['token'], {'select': 'id' if t != 'profiles' else 'id', 'limit': '1'}, count=True)
            n = supa.total_from(h)
            cells.append(f'<article class="card"><h3>{label}</h3><p><b>{n if n is not None else "؟"}</b></p>' + ('<small class="muted">لا توجد بيانات بعد</small>' if n == 0 else '') + '</article>')
        except (supa.SupaError, supa.SupaDown):
            cells.append(f'<article class="card"><h3>{label}</h3><p class="muted">تعذر القراءة</p></article>')
    return '<div class="notice warn">الأرقام مقروءة مباشرة من قاعدة البيانات بصلاحيتك. الإيراد والسحب معطّلان.</div><div class="grid three">' + ''.join(cells) + '</div>'

RENDER = {'/profile': profile, '/wallet': wallet, '/withdrawals': withdrawals, '/notifications': notifications, '/support': support, '/admin': admin}
