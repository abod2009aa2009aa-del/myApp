# إشترك Android — starter scaffold (not production-ready)

- Native Kotlin + Jetpack Compose + Material 3.
- `minSdk=26`, `targetSdk=36` (Android 16 stable target chosen from official Android SDK docs checked 2026-10-14).
- `allowBackup=false`, cleartext traffic disabled.
- Current UI is a starter preview; Supabase Auth/REST/Storage, FCM, real permission flows for microphone/camera/biometrics, deep links, secure session storage, certificate pinning, voice recording/upload, real account screens, and financial data queries are **not implemented**.
- No service-role key, Firebase credentials, or signing key is included.
- Do not treat local notification sample as remote push. It is explicitly a local-device demo.
- No release APK is included because this environment has not built or signed the Android project.
- CI signing requires GitHub Actions secrets; use a private repository and protect `main`.
- The workflow is a starting point and must be run and repaired in GitHub before any release can be considered verified.
