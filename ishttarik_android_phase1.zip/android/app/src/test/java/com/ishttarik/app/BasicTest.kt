package com.ishttarik.app

import org.junit.Assert.assertEquals
import org.junit.Test

class BasicTest {
    @Test fun developerLabelIsConfigured() {
        assertEquals("عبدالله", "عبدالله")
    }
}
