package com.ishttarik.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

private val Ink = Color(0xFF151226)
private val Panel = Color(0xFF25213E)
private val Pink = Color(0xFFEC4899)
private val Cyan = Color(0xFF22D3EE)
private const val DEVELOPER_NAME = "عبدالله"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannels(this)
        window.statusBarColor = android.graphics.Color.rgb(21,18,38)
        window.navigationBarColor = android.graphics.Color.rgb(21,18,38)
        setContent { IshttarikApp() }
    }
}

private fun createNotificationChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(NotificationManager::class.java)
        listOf(
            NotificationChannel("account_security", "الحساب والأمان", NotificationManager.IMPORTANCE_HIGH).apply { description = "تنبيهات أمان الحساب" },
            NotificationChannel("support", "الدعم", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "تحديثات تذاكر الدعم" },
            NotificationChannel("general", "عام", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "إشعارات عامة" }
        ).forEach(manager::createNotificationChannel)
    }
}

@Composable
private fun IshttarikApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("home") }
    var notificationAllowed by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    var micAllowed by remember { mutableStateOf(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    var cameraAllowed by remember { mutableStateOf(context.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var showRationale by remember { mutableStateOf(false) }
    var permissionTarget by remember { mutableStateOf("notifications") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        when(permissionTarget) {
            "notifications" -> notificationAllowed = granted
            "microphone" -> micAllowed = granted
            "camera" -> cameraAllowed = granted
        }
        showRationale = false
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Pink, secondary = Cyan, background = Ink, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Color(0xFF21162F)))).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("✦", color = Cyan, style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("إشترك", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("بواسطة $DEVELOPER_NAME", style = MaterialTheme.typography.labelMedium, color = Cyan)
                }
                Spacer(Modifier.weight(1f))
                Text("●", color = Pink)
            }
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("home" to "الرئيسية", "wallet" to "المحفظة", "settings" to "الإعدادات").forEach { (id,label) ->
                    FilterChip(selected = page == id, onClick = { page = id }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(14.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when(page) {
                    "home" -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                            Column(Modifier.padding(20.dp)) {
                                Text("أهلاً بك 👋", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text("منصة عربية للحساب والدعم والإشعارات.", color = Color.LightGray)
                                Spacer(Modifier.height(16.dp))
                                Text("الإعلانات", color = Cyan, fontWeight = FontWeight.Bold)
                                Text("غير مربوط بمزوّد إعلانات موثوق بعد. لن نعرض مشاهدات أو أرباح وهمية.", color = Color.White)
                            }
                        }
                        Tile("🔔", "الإشعارات", "فعّلها اختيارياً لتلقي تحديثات الحساب والدعم") { permissionTarget="notifications"; showRationale=true }
                        Tile("🎧", "الدعم الفني", "إرفاق الملفات والصور متاح عبر منتقي النظام في النسخة المتكاملة") { page="support" }
                        Tile("❓", "الأسئلة الشائعة", "الأرباح والسحب معطّلان حتى تجهيز المزود والتحقق") { page="faq" }
                    }
                    "wallet" -> {
                        Tile("محفظتك", "لا توجد بيانات مالية محمّلة من الخادم في هذه النسخة التمهيدية.", "لن نعرض رصيداً تجريبياً أو نحسب أرباحاً على الجهاز.") {}
                        Tile("السحب", "معطّل حالياً", "السحب غير متاح لأن withdrawals_enabled=false على الخادم.") {}
                    }
                    "settings" -> {
                        Tile("الأذونات", "حالة الإشعارات: ${if(notificationAllowed) "مسموح" else "غير مسموح"}\nحالة الميكروفون: ${if(micAllowed) "مسموح" else "غير مسموح"}\nحالة الكاميرا: ${if(cameraAllowed) "مسموح" else "غير مسموح"}", "يمكن تغييرها من إعدادات أندرويد.") {
                            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                        }
                        Tile("إشعار محلي تجريبي", "إشعار على الجهاز فقط، وليس Push من الخادم.", "لا يتصل بـ Firebase في هذه النسخة.") { sendLocalNotification(context) }
                        Tile("حول التطبيق", "إشترك • بواسطة $DEVELOPER_NAME", "نسخة تمهيدية، ليست جاهزة للإنتاج.") {}
                    }
                    "support" -> {
                        Tile("تذكرة الدعم", "إرسال النص والصوت والمرفقات إلى Storage الخاص غير متصل بعد.", "نحتاج ربط آمن وسياسات RLS قبل رفع أي ملف.") {}
                    }
                    else -> Tile("الأسئلة الشائعة", "لم يتم تفعيل الخدمات المالية أو الإعلانات.", "لن تظهر بيانات مالية وهمية.") {}
                }
            }
            Text("نسخة تطوير • لا توجد أرباح أو عمليات سحب فعلية", color = Color(0xFFB7B2D1), style = MaterialTheme.typography.labelSmall)
        }
        if (showRationale) {
            val permission = when(permissionTarget) { "microphone" -> Manifest.permission.RECORD_AUDIO; "camera" -> Manifest.permission.CAMERA; else -> Manifest.permission.POST_NOTIFICATIONS }
            AlertDialog(
                onDismissRequest = { showRationale=false },
                title = { Text("قبل منح الإذن") },
                text = { Text(when(permissionTarget) {
                    "microphone" -> "يُستخدم الميكروفون فقط لتسجيل رسالة صوتية لتذكرة الدعم. يمكنك التخطي."
                    "camera" -> "تُستخدم الكاميرا فقط لالتقاط مرفق اختياري. يمكنك التخطي."
                    else -> "تُستخدم الإشعارات لإخبارك بتحديثات الحساب والدعم. يمكنك المتابعة دون السماح."
                }) },
                confirmButton = { TextButton(onClick = { permissionLauncher.launch(permission); showRationale=false }) { Text("السماح") } },
                dismissButton = { TextButton(onClick = { showRationale=false; if(permissionTarget=="notifications") page="settings" }) { Text("ليس الآن") } }
            )
        }
    }
}

@Composable
private fun Tile(icon: String, title: String, body: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) {
            Text(icon, color = Cyan, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(body, color = Color(0xFFD3D0E4), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

private fun sendLocalNotification(context: Context) {
    val notification = NotificationCompat.Builder(context, "general")
        .setSmallIcon(R.drawable.ic_ishttarik)
        .setContentTitle("إشترك")
        .setContentText("هذا إشعار محلي على الجهاز، ليس Push حقيقياً.")
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)
        .build()
    if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
        NotificationManagerCompat.from(context).notify(1001, notification)
    }
}
