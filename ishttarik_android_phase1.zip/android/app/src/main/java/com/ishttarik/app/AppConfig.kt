package com.ishttarik.app

/** Keep display identity in one source file. */
object AppConfig {
    const val DEVELOPER_NAME = "عبدالله"
}
