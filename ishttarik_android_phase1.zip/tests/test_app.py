import sys, tempfile, threading, unittest, urllib.request, urllib.parse, http.cookiejar, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();app.DB_PATH=Path(cls.tmp.name)/'test.sqlite3';app.init_db();cls.s=app.ThreadingHTTPServer(('127.0.0.1',0),app.H);threading.Thread(target=cls.s.serve_forever,daemon=True).start();cls.url=f'http://127.0.0.1:{cls.s.server_port}'
 @classmethod
 def tearDownClass(cls):cls.s.shutdown();cls.s.server_close();cls.tmp.cleanup()
 def setUp(self):
  app.AUTH_ATTEMPTS.clear()
  with app.db() as c:c.execute('DELETE FROM profiles')
 def op(self):return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def post(self,op,path,email,pw):
  req=urllib.request.Request(self.url+path,data=urllib.parse.urlencode({'email':email,'password':pw}).encode(),headers={'Origin':self.url,'Content-Type':'application/x-www-form-urlencoded'})
  return op.open(req)
 def test_health_status(self):
  self.assertTrue(json.load(urllib.request.urlopen(self.url+'/health'))['ok']);d=json.load(urllib.request.urlopen(self.url+'/api/status'));self.assertEqual(len(d['services']),3);self.assertFalse(any(x['status']=='ready' for x in d['services']))
 def test_register_login_logout(self):
  op=self.op();r=self.post(op,'/register','test@example.com','long-test-password');self.assertEqual(r.status,200);self.assertIn('أهلاً بيك',r.read().decode())
  try:urllib.request.urlopen(self.url+'/logout')
  except urllib.error.HTTPError as e:self.assertEqual(e.code,405)
  else:self.fail('GET logout must be disabled')
  req=urllib.request.Request(self.url+'/logout',data=b'',headers={'Origin':self.url},method='POST');r=op.open(req);self.assertEqual(r.status,200)
  r=self.post(op,'/login','test@example.com','long-test-password');self.assertEqual(r.status,200)
 def test_large_post_is_rejected(self):
  body=b'x'*16385;req=urllib.request.Request(self.url+'/login',data=body,headers={'Origin':self.url},method='POST')
  try:urllib.request.urlopen(req)
  except urllib.error.HTTPError as e:self.assertEqual(e.code,413)
  else:self.fail('oversized request must be rejected')
 def test_security_headers(self):
  r=urllib.request.urlopen(self.url+'/');self.assertEqual(r.headers.get('X-Content-Type-Options'),'nosniff');self.assertEqual(r.headers.get('X-Frame-Options'),'DENY');self.assertIn("script-src 'self'",r.headers.get('Content-Security-Policy',''));self.assertNotIn("unsafe-inline",r.headers.get('Content-Security-Policy',''))
 def test_duplicate_and_bad_password(self):
  op=self.op()
  self.post(op,'/register','test@example.com','long-test-password').read()
  r=self.post(op,'/register','test@example.com','long-test-password');self.assertIn('هذا البريد مسجل مسبقاً',r.read().decode())
  r=self.post(op,'/login','test@example.com','wrong-password');self.assertIn('بيانات الدخول غير صحيحة',r.read().decode())
 def test_short_password(self):
  r=self.post(self.op(),'/register','short@example.com','short');self.assertIn('10 أحرف على الأقل',r.read().decode())
 def test_protected_pages_and_admin_denial(self):
  anon=self.op(); r=anon.open(self.url+'/wallet'); self.assertEqual(r.status,200); self.assertIn('/login',r.url)
  op=self.op(); self.post(op,'/register','ordinary@example.com','long-test-password').read()
  try: op.open(self.url+'/admin')
  except urllib.error.HTTPError as e: self.assertEqual(e.code,403)
  else: self.fail('ordinary user must not access admin')
 def test_reject_foreign_origin(self):
  req=urllib.request.Request(self.url+'/login',data=urllib.parse.urlencode({'email':'a@example.com','password':'long-test-password'}).encode(),headers={'Origin':'https://attacker.example','Content-Type':'application/x-www-form-urlencoded'})
  try: urllib.request.urlopen(req)
  except urllib.error.HTTPError as e: self.assertEqual(e.code,403)
  else: self.fail('foreign Origin must be rejected')
if __name__=='__main__':unittest.main(verbosity=2)
