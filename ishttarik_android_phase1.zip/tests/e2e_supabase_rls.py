"""REAL end-to-end RLS/ledger test. Run ONLY against a disposable TEST project (ledger rows are immutable).
Required env: SUPABASE_URL, SUPABASE_ANON_KEY, ISH_E2E_CONFIRM_TEST_PROJECT=yes,
  ISH_E2E_EMAIL_A / ISH_E2E_PASSWORD_A / ISH_E2E_EMAIL_B / ISH_E2E_PASSWORD_B  (two pre-created, confirmed, NON-admin users)
Optional: ISH_E2E_SERVICE_ROLE_KEY (test project only; enables settlement/ledger tests, read from env, never stored).
Prints PASS/FAIL per check, never tokens. Exit code 1 on any failure."""
import json, os, sys, threading, uuid, urllib.request, urllib.error, urllib.parse
from decimal import Decimal as D
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..')); import ledger
URL = os.environ.get('SUPABASE_URL', '').rstrip('/'); KEY = os.environ.get('SUPABASE_ANON_KEY', ''); SRV = os.environ.get('ISH_E2E_SERVICE_ROLE_KEY', '')
def call(method, path, body=None, token=None, key=None, prefer=None):
    h = {'apikey': key or KEY, 'Authorization': 'Bearer ' + (token or key or KEY), 'Content-Type': 'application/json'}
    if prefer: h['Prefer'] = prefer
    r = urllib.request.Request(URL + path, json.dumps(body).encode() if body is not None else None, h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=20) as x: raw = x.read(); return x.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        raw = e.read()
        try: return e.code, json.loads(raw)
        except Exception: return e.code, None
res = []
def check(name, ok): res.append(ok); print(('PASS ' if ok else 'FAIL ') + name)
def login(e, p): s, j = call('POST', '/auth/v1/token?grant_type=password', {'email': e, 'password': p}); assert s == 200, f'login failed ({s})'; return j['access_token'], j['user']['id'], j['user']
def denied(s): return s in (401, 403) or s == 404
def main():
    if os.environ.get('ISH_E2E_CONFIRM_TEST_PROJECT') != 'yes' or not URL or not KEY: sys.exit('Refusing to run: set ISH_E2E_CONFIRM_TEST_PROJECT=yes and SUPABASE_URL/ANON_KEY (TEST project only).')
    ta, a, ua = login(os.environ['ISH_E2E_EMAIL_A'], os.environ['ISH_E2E_PASSWORD_A']); tb, b, ub = login(os.environ['ISH_E2E_EMAIL_B'], os.environ['ISH_E2E_PASSWORD_B'])
    check('users are not admin (app_metadata)', ua.get('app_metadata', {}).get('platform_role') != 'admin' and ub.get('app_metadata', {}).get('platform_role') != 'admin')
    s, j = call('GET', '/rest/v1/profiles?select=id', token=ta); check('A sees only own profile', s == 200 and [x['id'] for x in j] == [a])
    s, j = call('GET', f'/rest/v1/profiles?id=eq.{b}', token=ta); check("A cannot read B's profile", s == 200 and j == [])
    call('PATCH', f'/rest/v1/profiles?id=eq.{b}', {'display_name': 'hacked'}, ta, prefer='return=representation')
    s, j = call('GET', f'/rest/v1/profiles?id=eq.{b}&select=display_name', token=tb); check("A cannot modify B's profile", s == 200 and j and j[0]['display_name'] != 'hacked')
    s, _ = call('PATCH', f'/rest/v1/profiles?id=eq.{a}', {'created_at': '2000-01-01'}, ta); check('A cannot edit non-granted profile columns', s in (400, 401, 403))
    call('PUT', '/auth/v1/user', {'data': {'platform_role': 'admin'}}, ta); s, j = call('POST', '/auth/v1/token?grant_type=password', {'email': os.environ['ISH_E2E_EMAIL_A'], 'password': os.environ['ISH_E2E_PASSWORD_A']})
    check('user cannot become admin via user_metadata', j['user'].get('app_metadata', {}).get('platform_role') != 'admin')
    s, _ = call('PUT', '/auth/v1/user', {'app_metadata': {'platform_role': 'admin'}}, ta); s2, j2 = call('GET', '/auth/v1/user', token=ta)
    check('user cannot set app_metadata admin', j2['app_metadata'].get('platform_role') != 'admin')
    for t, row in (('wallet_transactions', {'user_id': a, 'transaction_type': 'earning', 'amount': 5, 'status': 'posted'}), ('revenue_records', {'user_id': a, 'gross_amount': 1, 'platform_amount': 0, 'user_amount': 1}),
                   ('verified_ad_events', {'user_id': a}), ('payment_events', {'provider': 'x'}), ('audit_logs', {'action': 'x', 'entity_type': 'x'}), ('ad_campaigns', {'title': 'x'})):
        s, _ = call('POST', '/rest/v1/' + t, row, ta); check(f'A cannot insert into {t}', s in (401, 403))
    s, j = call('GET', '/rest/v1/payment_events?select=id', token=ta); check('A cannot read payment_events', s in (401, 403) or j == [])
    s, j = call('GET', '/rest/v1/audit_logs?select=id', token=ta); check('A cannot read audit_logs', s in (401, 403) or j == [])
    s, _ = call('POST', '/rest/v1/withdrawal_requests', {'user_id': a, 'requested_amount': 1, 'currency': 'IQD'}, ta); check('direct withdrawal insert denied (revoke_direct_withdrawal_insert)', s in (401, 403))
    s, j = call('POST', '/rest/v1/rpc/request_withdrawal', {'p_amount': 1, 'p_currency': 'IQD'}, ta); check('request_withdrawal refuses while disabled', s >= 400 and 'withdrawals_disabled' in json.dumps(j))
    for fn in ('settle_revenue', 'reverse_revenue'):
        s, _ = call('POST', '/rest/v1/rpc/' + fn, {}, ta); check(f'A cannot call {fn}', s in (401, 403, 404))
    s, _ = call('POST', '/rest/v1/rpc/admin_update_settings', {'p_user_share_bps': 9999}, ta); check('non-admin cannot change settings', s >= 400)
    s, j = call('GET', '/rest/v1/profiles?select=id'); check('anon (no user) cannot read profiles', s in (401, 403) or j == [])
    s, j = call('POST', '/rest/v1/support_tickets', {'user_id': b, 'subject': 'x', 'message': 'y'}, ta); check('A cannot create ticket for B', s in (401, 403))
    s, j = call('POST', '/rest/v1/support_tickets', {'user_id': a, 'subject': 'e2e', 'message': 'y'}, ta); check('A can create own ticket', s in (200, 201))
    s, j = call('GET', '/rest/v1/support_tickets?select=user_id', token=tb); check("B cannot see A's tickets", s == 200 and all(x['user_id'] == b for x in j))
    if SRV:
        ref = 'e2e-' + uuid.uuid4().hex; sr = lambda path, body: call('POST', '/rest/v1/rpc/' + path, body, SRV, key=SRV)
        s, j = sr('settle_revenue', {'p_source_reference': ref, 'p_user_id': a, 'p_gross': 1.00, 'p_currency': 'IQD', 'p_provider': 'e2e'})
        print('INFO settle_revenue status', s, '(400 revenue_disabled is expected until the owner enables it in a TEST project)')
        if s in (200, 204):
            rs = []; th = [threading.Thread(target=lambda: rs.append(sr('settle_revenue', {'p_source_reference': ref, 'p_user_id': a, 'p_gross': 1.00, 'p_currency': 'IQD', 'p_provider': 'e2e'})[0])) for _ in range(8)]
            [t.start() for t in th]; [t.join() for t in th]
            s, rev = call('GET', f'/rest/v1/revenue_records?source_reference=eq.{ref}', token=ta); s, tx = call('GET', f'/rest/v1/wallet_transactions?idempotency_key=eq.earning:{ref}', token=ta)
            check('8 concurrent settlements -> 1 revenue row and 1 earning', len(rev) == 1 and len(tx) == 1)
            u, p = ledger.split('1.00'); check('split is 65/35 exactly', D(str(rev[0]['user_amount'])) == u and D(str(rev[0]['platform_amount'])) == p)
            s, _ = call('DELETE', f'/rest/v1/wallet_transactions?idempotency_key=eq.earning:{ref}', None, SRV, key=SRV); check('ledger delete blocked even for service_role', s >= 400)
            s, _ = call('PATCH', f'/rest/v1/wallet_transactions?idempotency_key=eq.earning:{ref}', {'amount': 999}, SRV, key=SRV); check('ledger amount update blocked even for service_role', s >= 400)
            sr('reverse_revenue', {'p_source_reference': ref, 'p_reason': 'e2e'}); sr('reverse_revenue', {'p_source_reference': ref, 'p_reason': 'e2e'})
            s, tx = call('GET', f'/rest/v1/wallet_transactions?reference_id=eq.{rev[0]["id"]}&select=transaction_type,amount,currency,status', token=ta)
            check('reversal recorded exactly once', sum(1 for x in tx if x['transaction_type'] == 'reversal') == 1)
            s, bal = call('GET', f'/rest/v1/wallet_balances?user_id=eq.{a}', token=ta); s2, allrows = call('GET', f'/rest/v1/wallet_transactions?user_id=eq.{a}&select=transaction_type,amount,currency,status', token=ta)
            exp = ledger.balances(allrows) if s2 == 200 else {}
            check('wallet_balances view equals reference ledger.balances', s == 200 and all(D(str(x['available'])) == exp.get(x['currency'], {}).get('available') and D(str(x['held'])) == exp.get(x['currency'], {}).get('held') for x in bal) and len(bal) == len(exp))
    else: print('SKIP settlement/ledger checks (ISH_E2E_SERVICE_ROLE_KEY not provided)')
    print(f'{sum(res)}/{len(res)} checks passed'); sys.exit(0 if all(res) else 1)
if __name__ == '__main__': main()
