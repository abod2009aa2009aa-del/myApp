import sys, random, unittest
from decimal import Decimal as D
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import ledger
class LedgerTests(unittest.TestCase):
    def test_example_one_dollar(self):
        self.assertEqual(ledger.split('1.00'), (D('0.65'), D('0.35')))
    def test_never_leaks_or_overpays(self):
        r = random.Random(7)
        for _ in range(3000):
            net = D(r.randint(0, 10**9)) / 100; bps = r.choice([6500, 6500, 5000, 0, 10000, r.randint(0, 10000)])
            u, p = ledger.split(net, bps)
            self.assertEqual(u + p, net); self.assertGreaterEqual(p, 0); self.assertLessEqual(u, net * bps / 10000)
    def test_micro_amount_rounds_user_down(self):
        self.assertEqual(ledger.split('0.01'), (D('0.00'), D('0.01')))
    def test_rejects_bad_input(self):
        for bad in ('-1', '1.005'):
            with self.assertRaises(ValueError): ledger.split(bad)
        with self.assertRaises(ValueError): ledger.split('1', 10001)
    def test_balances(self):
        rows = [dict(currency='IQD', amount=D('65'), transaction_type='earning', status='posted'),
                dict(currency='IQD', amount=D('20'), transaction_type='withdrawal_hold', status='posted'),
                dict(currency='IQD', amount=D('5'), transaction_type='earning', status='pending')]
        b = ledger.balances(rows)['IQD']
        self.assertEqual((b['available'], b['held'], b['pending']), (D('45'), D('20'), D('5')))
        rows.append(dict(currency='IQD', amount=D('20'), transaction_type='withdrawal_paid', status='posted'))
        b = ledger.balances(rows)['IQD']; self.assertEqual((b['available'], b['held']), (D('45'), D('0')))
        rows.append(dict(currency='IQD', amount=D('65'), transaction_type='reversal', status='posted'))
        self.assertEqual(ledger.balances(rows)['IQD']['available'], D('-20'))
    def test_reversal_debt_separate_when_balance_is_insufficient(self):
        from ledger import apply_reversal
        posted, debt = apply_reversal('3.00', '8.00')
        self.assertEqual(posted, D('3.00'))
        self.assertEqual(debt, D('5.00'))

    def test_future_earning_offsets_reversal_debt(self):
        from ledger import apply_earning_to_debt
        available, paid, remaining = apply_earning_to_debt('4.00', '6.00')
        self.assertEqual((available, paid, remaining), (D('0.00'), D('4.00'), D('2.00')))
        available, paid, remaining = apply_earning_to_debt('5.00', remaining)
        self.assertEqual((available, paid, remaining), (D('3.00'), D('2.00'), D('0.00')))

    def test_withdrawal_blocked_while_debt_outstanding(self):
        from ledger import can_withdraw
        ok, reason = can_withdraw('100.00', '10.00', '1.00', False, True, '0.01')
        self.assertFalse(ok)
        self.assertEqual(reason, 'outstanding_reversal_debt')

    def test_can_withdraw(self):
        f = ledger.can_withdraw
        self.assertEqual(f('50', '10', '5', False, True), (True, 'ok'))
        self.assertEqual(f('50', '10', '5', False, False)[1], 'withdrawals_disabled')
        self.assertEqual(f('50', '60', '5', False, True)[1], 'insufficient_balance')
        self.assertEqual(f('50', '10', '5', True, True)[1], 'open_request_exists')
        self.assertEqual(f('50', '2', '5', False, True)[1], 'below_minimum')
        self.assertEqual(f('50', '-1', '5', False, True)[1], 'invalid_amount')
if __name__ == '__main__': unittest.main(verbosity=2)
