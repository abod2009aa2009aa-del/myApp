"""App-logic tests in Supabase mode against tests/mock_supabase.py (a MOCK; not proof of real RLS)."""
import sys, os, re, json, base64, threading, unittest, http.client, urllib.parse
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
import app, supa, pages_supa
from mock_supabase import Mock

class Client:
    def __init__(s, url): s.url = urllib.parse.urlparse(url); s.c = {}; s.raw = []
    def req(s, method, path, data=None, headers=None):
        h = {'Origin': f'http://{s.url.hostname}:{s.url.port}', 'Content-Type': 'application/x-www-form-urlencoded'}
        h.update(headers or {}); h = {k: v for k, v in h.items() if v is not None}
        if s.c: h['Cookie'] = '; '.join(f'{k}={v}' for k, v in s.c.items())
        cn = http.client.HTTPConnection(s.url.hostname, s.url.port, timeout=15)
        cn.request(method, path, urllib.parse.urlencode(data).encode() if data else None, h); r = cn.getresponse(); body = r.read().decode('utf8', 'replace')
        s.raw = [v for k, v in r.getheaders() if k.lower() == 'set-cookie']
        for sc in s.raw:
            name, val = sc.split(';')[0].split('=', 1)
            if 'Max-Age=0' in sc: s.c.pop(name, None)
            else: s.c[name] = val
        loc = r.getheader('Location'); cn.close(); return r.status, body, loc

class T(unittest.TestCase):
    @classmethod
    def setUpClass(c):
        c.m = Mock(); url = c.m.start(); c.env = {k: os.environ.get(k) for k in ('SUPABASE_URL', 'SUPABASE_ANON_KEY')}
        os.environ['SUPABASE_URL'] = url; os.environ['SUPABASE_ANON_KEY'] = 'sb_publishable_testkey'
        c.old = (app.SUPA, supa.CACHE_TTL); app.SUPA = True; supa.CACHE_TTL = 0
        c.s = app.ThreadingHTTPServer(('127.0.0.1', 0), app.H); threading.Thread(target=c.s.serve_forever, daemon=True).start(); c.url = f'http://127.0.0.1:{c.s.server_port}'
    @classmethod
    def tearDownClass(c):
        c.s.shutdown(); c.s.server_close(); app.SUPA, supa.CACHE_TTL = c.old
        for k, v in c.env.items(): os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
        try: c.m.stop()
        except Exception: pass
    def setUp(s):
        s.m.users.clear(); s.m.at.clear(); s.m.rt.clear(); s.m.expired.clear(); s.m.log.clear(); s.m.confirm_required = False
        for t in s.m.tables.values(): t.clear()
        app.AUTH_ATTEMPTS.clear()
    def login(s, email, pw='long-test-password'):
        c = Client(s.url); st, b, loc = c.req('POST', '/login', {'email': email, 'password': pw}); return c, st, b, loc

    def test_register_sets_httponly_cookies_and_hides_tokens(s):
        c = Client(s.url); st, b, loc = c.req('POST', '/register', {'email': 'a@example.com', 'password': 'long-test-password'})
        s.assertEqual((st, loc), (303, '/dashboard')); s.assertEqual(set(c.c), {'ish_at', 'ish_rt'})
        s.assertTrue(all('HttpOnly' in x and 'SameSite=Lax' in x for x in c.raw))
        st, body, _ = c.req('GET', '/dashboard'); s.assertEqual(st, 200); s.assertIn('a@example.com', body)
        s.assertNotIn(c.c['ish_at'], body); s.assertNotIn(c.c['ish_rt'], body)
    def test_register_with_email_confirmation_gives_no_session(s):
        s.m.confirm_required = True; c = Client(s.url)
        st, b, _ = c.req('POST', '/register', {'email': 'n@example.com', 'password': 'long-test-password'})
        s.assertEqual(c.c, {}); s.assertIn('رسالة تأكيد', b)
        st, b, _ = c.req('POST', '/login', {'email': 'n@example.com', 'password': 'long-test-password'}); s.assertIn('أكّد بريدك', b); s.assertEqual(c.c, {})
    def test_wrong_password_arabic_and_no_raw_provider_text(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, st, b, _ = s.login('a@example.com', 'bad-password-xx')
        s.assertIn('بيانات الدخول غير صحيحة', b); s.assertNotIn('RAW', b); s.assertEqual(c.c, {})
    def test_two_users_data_calls_use_only_own_token(s):
        a = s.m.add_user('a@example.com', 'long-test-password'); b = s.m.add_user('b@example.com', 'long-test-password')
        s.m.tables['wallet_transactions'] += [dict(user_id=a, transaction_type='earning', amount=11.5, currency='IQD', status='posted', created_at='2026-10-01'),
                                              dict(user_id=b, transaction_type='earning', amount=987.25, currency='IQD', status='posted', created_at='2026-10-02')]
        s.m.tables['notifications'].append(dict(user_id=b, title='سر المستخدم ب', body='x', created_at='2026-10-02', read_at=None))
        ca, *_ = s.login('a@example.com'); s.m.log.clear()
        for p in ('/wallet', '/notifications', '/support', '/profile', '/withdrawals'): s.assertEqual(ca.req('GET', p)[0], 200)
        _, w, _ = ca.req('GET', '/wallet'); s.assertIn('11.5', w); s.assertNotIn('987.25', w)
        _, n, _ = ca.req('GET', '/notifications'); s.assertNotIn('سر المستخدم ب', n); s.assertIn('لا توجد إشعارات', n)
        calls = [x for x in s.m.log if x['path'].startswith('/rest/')]; s.assertTrue(calls)
        s.assertTrue(all(x['auth'] == 'Bearer ' + ca.c['ish_at'] for x in calls)); s.assertTrue(all('service' not in x['auth'].lower() for x in calls))
    def test_empty_wallet_shows_no_invented_numbers(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com'); _, b, _ = c.req('GET', '/wallet')
        s.assertIn('لا توجد معاملات مالية', b); s.assertNotRegex(b, r'\d+\.\d\d')
    def test_admin_requires_app_metadata_not_user_metadata(s):
        s.m.add_user('u@example.com', 'long-test-password', user_md={'platform_role': 'admin'}); s.m.add_user('adm@example.com', 'long-test-password', app_md={'platform_role': 'admin'})
        cu, *_ = s.login('u@example.com'); s.assertEqual(cu.req('GET', '/admin')[0], 403)
        ca, *_ = s.login('adm@example.com'); st, b, _ = ca.req('GET', '/admin'); s.assertEqual(st, 200); s.assertIn('لا توجد بيانات بعد', b)
        s.assertEqual(Client(s.url).req('GET', '/admin')[2], '/login')
    def test_expired_access_token_refreshes(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com'); old = c.c['ish_at']; s.m.expired.add(old); s.m.log.clear()
        st, b, _ = c.req('GET', '/profile'); s.assertEqual(st, 200); s.assertNotEqual(c.c['ish_at'], old)
        s.assertTrue(any(x['query'].get('grant_type') == 'refresh_token' for x in s.m.log))
    def test_logout_revokes_server_side_and_clears_cookies(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com'); tok = c.c['ish_at']
        st, _, loc = c.req('GET', '/logout'); s.assertEqual(st, 405); s.assertEqual(c.c.get('ish_at'), tok)
        st, _, loc = c.req('POST', '/logout', {}); s.assertEqual(loc, '/'); s.assertEqual(c.c, {}); s.assertNotIn(tok, s.m.at)
    def test_support_ticket_user_id_comes_from_session_only(s):
        a = s.m.add_user('a@example.com', 'long-test-password'); b = s.m.add_user('b@example.com', 'long-test-password'); c, *_ = s.login('a@example.com')
        c.req('POST', '/support', {'subject': 'مشكلة', 'message': 'نص', 'user_id': b}); t = s.m.tables['support_tickets']
        s.assertEqual(len(t), 1); s.assertEqual(t[0]['user_id'], a)
        s.assertEqual(c.req('POST', '/support', {'subject': '', 'message': ''})[0], 200); s.assertEqual(len(t), 1)
    def test_profile_update_only_display_name_sanitized(s):
        a = s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com')
        c.req('POST', '/profile', {'display_name': 'س\x00ام' + 'x' * 200, 'role': 'admin', 'id': 'other'})
        p = [x for x in s.m.log if x['method'] == 'PATCH'][-1]; s.assertEqual(list(p['body']), ['display_name']); s.assertEqual(p['query'], {'id': 'eq.' + a})
        s.assertLessEqual(len(s.m.tables['profiles'][0]['display_name']), 80); s.assertNotIn('\x00', s.m.tables['profiles'][0]['display_name'])
    def test_csrf_foreign_and_missing_origin_rejected_on_data_posts(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com')
        s.assertEqual(c.req('POST', '/profile', {'display_name': 'x'}, {'Origin': 'https://evil.example'})[0], 403)
        s.assertEqual(c.req('POST', '/profile', {'display_name': 'x'}, {'Origin': None})[0], 403)
        s.assertEqual(c.req('POST', '/profile', {'display_name': 'x'})[0], 303)
    def test_recovery_is_generic_and_update_password_needs_token(s):
        s.m.add_user('a@example.com', 'long-test-password'); c = Client(s.url)
        _, b1, _ = c.req('POST', '/reset-password', {'email': 'a@example.com'}); _, b2, _ = c.req('POST', '/reset-password', {'email': 'nobody@example.com'})
        s.assertIn('فسيصلك رابط', b1); s.assertIn('فسيصلك رابط', b2)
        _, b, _ = c.req('POST', '/update-password', {'password': 'new-long-password'}); s.assertIn('غير صالح', b)
    def test_logout_clears_browser_cookie_when_provider_down_and_discloses_uncertainty(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com'); tok = c.c['ish_at']
        os.environ['SUPABASE_URL'] = 'http://127.0.0.1:9'
        try:
            st, body, loc = c.req('POST', '/logout', {})
            s.assertEqual(loc, '/?logout=local-only'); s.assertEqual(c.c, {})
            self_asserted = 'تعذّر تأكيد إبطال الجلسة' in c.req('GET', loc)[1]
            s.assertTrue(self_asserted); s.assertIn(tok, s.m.at)
        finally: os.environ['SUPABASE_URL'] = s.m.url

    def test_provider_down_shows_error_and_never_fake_success(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com')
        os.environ['SUPABASE_URL'] = 'http://127.0.0.1:9'
        try:
            c2 = Client(s.url); st, b, _ = c2.req('POST', '/login', {'email': 'a@example.com', 'password': 'long-test-password'})
            s.assertIn('تعذر الاتصال', b); s.assertEqual(c2.c, {})
            s.assertEqual(c.req('GET', '/wallet')[0], 503); s.assertEqual(c.req('GET', '/health')[0], 503)
        finally: os.environ['SUPABASE_URL'] = s.m.url
    def test_data_failure_shows_error_not_numbers(s):
        s.m.add_user('a@example.com', 'long-test-password'); c, *_ = s.login('a@example.com'); orig = pages_supa.get
        pages_supa.get = lambda *a, **k: None
        try: _, b, _ = c.req('GET', '/wallet'); s.assertIn('تعذر قراءة البيانات', b)
        finally: pages_supa.get = orig
    def test_public_site_url_requires_https(s):
        with s.assertRaises(supa.SupaConfigError): app.validate_site_url('http://example.com', True)
        app.validate_site_url('http://127.0.0.1:8000', True)
        app.validate_site_url('https://example.com', True)

    def test_config_rejects_secret_keys_and_plain_http(s):
        def jwt(role): return 'h.' + base64.urlsafe_b64encode(json.dumps({'role': role}).encode()).decode().rstrip('=') + '.s'
        for url, key in (('https://x.supabase.co', jwt('service_role')), ('https://x.supabase.co', 'sb_' + 'secret_abc'), ('http://example.com', 'sb_publishable_k')):
            os.environ['SUPABASE_URL'] = url; os.environ['SUPABASE_ANON_KEY'] = key
            with s.assertRaises(supa.SupaConfigError): supa.validate_config()
        os.environ['SUPABASE_URL'] = 'https://x.supabase.co'; os.environ['SUPABASE_ANON_KEY'] = jwt('anon'); supa.validate_config()
        os.environ['SUPABASE_URL'] = s.m.url; os.environ['SUPABASE_ANON_KEY'] = 'sb_publishable_testkey'
    def test_no_secrets_in_project_files(s):
        pats = [re.compile(r'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}'), re.compile('sb_' + r'secret_[A-Za-z0-9]{8,}')]
        for f in ROOT.rglob('*'):
            if f.is_file() and f.suffix in ('.py', '.js', '.md', '.sql', '.example', '.html', '.css') and 'data' not in f.parts:
                t = f.read_text('utf8', 'ignore')
                for p in pats: s.assertIsNone(p.search(t), f'secret-like string in {f}')
        env = (ROOT / '.env.example').read_text()
        s.assertIsNone(re.search(r'^\s*[A-Za-z_]*SERVICE_ROLE[A-Za-z_]*\s*=', env, re.M | re.I))
if __name__ == '__main__': unittest.main(verbosity=2)
