"""MOCK of Supabase Auth + PostgREST used ONLY to test this app's own logic offline.
Its RLS simulation is a stand-in: it proves nothing about the real Postgres policies.
Real RLS is verified by tests/e2e_supabase_rls.py against a real test project."""
import json, secrets, threading, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

class Mock:
    def __init__(self):
        self.users = {}; self.at = {}; self.rt = {}; self.expired = set(); self.log = []; self.recovers = []
        self.confirm_required = False
        self.tables = {t: [] for t in ('profiles', 'wallet_transactions', 'support_tickets', 'notifications', 'withdrawal_requests', 'ad_campaigns', 'verified_ad_events', 'revenue_records')}
    def add_user(self, email, pw, confirmed=True, app_md=None, user_md=None):
        uid = secrets.token_hex(8)
        self.users[email] = {'id': uid, 'email': email, 'pw': pw, 'confirmed': confirmed, 'app_md': app_md or {}, 'user_md': user_md or {}}
        self.tables['profiles'].append({'id': uid, 'display_name': ''}); return uid
    def session(self, u):
        a, r = 'at_' + secrets.token_hex(12), 'rt_' + secrets.token_hex(12)
        self.at[a] = u['email']; self.rt[r] = u['email']
        return {'access_token': a, 'refresh_token': r, 'expires_in': 3600, 'token_type': 'bearer', 'user': self.pub(u)}
    def pub(self, u):
        return {'id': u['id'], 'email': u['email'], 'app_metadata': {'provider': 'email', **u['app_md']}, 'user_metadata': u['user_md']}
    def start(self):
        m = self
        class H(BaseHTTPRequestHandler):
            def log_message(s, *a): pass
            def out(s, code, obj=None, hdr=None):
                b = json.dumps(obj).encode() if obj is not None else b''
                s.send_response(code); s.send_header('Content-Type', 'application/json'); s.send_header('Content-Length', str(len(b)))
                for k, v in (hdr or {}).items(): s.send_header(k, v)
                s.end_headers(); s.wfile.write(b)
            def body(s):
                n = int(s.headers.get('Content-Length', 0)); return json.loads(s.rfile.read(n) or b'{}') if n else {}
            def user(s):
                t = s.headers.get('Authorization', '')[7:]
                e = m.at.get(t)
                if not e or t in m.expired: return None, t
                return m.users[e], t
            def route(s, method):
                p = urllib.parse.urlparse(s.path); q = dict(urllib.parse.parse_qsl(p.query)); path = p.path
                b = s.body() if method in ('POST', 'PUT', 'PATCH') else {}
                m.log.append({'method': method, 'path': path, 'auth': s.headers.get('Authorization', ''), 'apikey': s.headers.get('apikey', ''), 'body': b, 'query': q})
                if path == '/auth/v1/health': return s.out(200, {'ok': True})
                if path == '/auth/v1/signup':
                    em = b.get('email')
                    if em in m.users or m.confirm_required:
                        if em not in m.users: m.add_user(em, b['password'], confirmed=False)
                        return s.out(200, {'id': 'x', 'email': em})
                    m.add_user(em, b['password']); return s.out(200, m.session(m.users[em]))
                if path == '/auth/v1/token':
                    if q.get('grant_type') == 'password':
                        u = m.users.get(b.get('email'))
                        if not u or u['pw'] != b.get('password'): return s.out(400, {'error_code': 'invalid_credentials', 'msg': 'Invalid login credentials RAW'})
                        if not u['confirmed']: return s.out(400, {'error_code': 'email_not_confirmed', 'msg': 'x'})
                        return s.out(200, m.session(u))
                    e = m.rt.get(b.get('refresh_token'))
                    if not e: return s.out(400, {'error_code': 'refresh_token_not_found'})
                    return s.out(200, m.session(m.users[e]))
                if path == '/auth/v1/recover': m.recovers.append(b.get('email')); return s.out(200, {})
                if path.startswith('/auth/v1/'):
                    u, t = s.user()
                    if not u: return s.out(401, {'error_code': 'bad_jwt', 'msg': 'invalid JWT'})
                    if path == '/auth/v1/user' and method == 'GET': return s.out(200, m.pub(u))
                    if path == '/auth/v1/user' and method == 'PUT': u['pw'] = b.get('password', u['pw']); return s.out(200, m.pub(u))
                    if path == '/auth/v1/logout':
                        for k in [k for k, v in m.at.items() if v == u['email']]: del m.at[k]
                        for k in [k for k, v in m.rt.items() if v == u['email']]: del m.rt[k]
                        return s.out(204)
                if path.startswith('/rest/v1/'):
                    u, t = s.user()
                    if not u: return s.out(401, {'code': 'PGRST301', 'message': 'JWT invalid'})
                    uid = u['id']; admin = u['app_md'].get('platform_role') == 'admin'; tb = path[9:]
                    if method == 'GET':
                        if tb == 'wallet_balances':
                            agg = {}
                            for r in m.tables['wallet_transactions']:
                                if r['user_id'] != uid and not admin: continue
                                a = agg.setdefault((r['user_id'], r['currency']), {'user_id': r['user_id'], 'currency': r['currency'], 'available': 0, 'pending': 0, 'held': 0})
                                if r['status'] == 'posted': a['available'] += r['amount'] if r['transaction_type'] == 'earning' else 0
                            rows = list(agg.values())
                        else:
                            rows = list(m.tables[tb])
                            if not admin: rows = [r for r in rows if (r['id'] == uid if tb == 'profiles' else (r.get('status') == 'active' if tb == 'ad_campaigns' else r.get('user_id') == uid))]
                        for k, v in q.items():
                            if v.startswith('eq.') and k not in ('select', 'order', 'limit'): rows = [r for r in rows if str(r.get(k)) == v[3:]]
                        total = len(rows)
                        if 'limit' in q: rows = rows[:int(q['limit'])]
                        cr = (f'0-{max(len(rows)-1, 0)}/{total}' if total else '*/0')
                        return s.out(200, rows, {'Content-Range': cr})
                    if method == 'POST':
                        if tb == 'support_tickets' and b.get('user_id') == uid:
                            m.tables[tb].append({**b, 'status': 'open', 'staff_reply': None, 'created_at': '2026-10-12'}); return s.out(201)
                        return s.out(403, {'code': '42501', 'message': 'RLS'})
                    if method == 'PATCH' and tb == 'profiles':
                        if not set(b) <= {'display_name', 'avatar_url'}: return s.out(403, {'code': '42501'})
                        for r in m.tables[tb]:
                            if r['id'] == uid and q.get('id') == 'eq.' + uid: r.update(b)
                        return s.out(204)
                s.out(404, {'message': 'nf'})
            def do_GET(s): s.route('GET')
            def do_POST(s): s.route('POST')
            def do_PUT(s): s.route('PUT')
            def do_PATCH(s): s.route('PATCH')
        self.srv = ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f'http://127.0.0.1:{self.srv.server_port}'; return self.url
    def stop(self):
        self.srv.shutdown(); self.srv.server_close()
