#!/usr/bin/env python3
"""إشترك starter: local-only app, SQLite accounts, no ad/payment integration."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
from http.cookies import SimpleCookie
from pathlib import Path
import sqlite3, os, secrets, hashlib, hmac, json, html, time, mimetypes, ipaddress
import supa, pages_supa
from contextlib import contextmanager
ROOT=Path(__file__).resolve().parent
DB_PATH=Path(os.environ.get('ISHTARIK_DB', ROOT/'data'/'ishttarik.sqlite3'))
PORT=int(os.environ.get('PORT','8000')); HOST=os.environ.get('HOST','127.0.0.1')
COOKIE='ishttarik_session'; TTL=604800
SUPA=supa.enabled()
if SUPA: supa.validate_config()
def validate_site_url(site_url, supa_mode=True):
 if not site_url or not supa_mode:return
 parsed=urlparse(site_url)
 if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('','/'):
  raise supa.SupaConfigError('SITE_URL must be an origin only, without credentials, query, fragment, or path')
 if parsed.scheme!='https' and (parsed.hostname or '').lower() not in ('localhost','127.0.0.1','::1'):
  raise supa.SupaConfigError('SITE_URL must use https outside localhost')
validate_site_url(os.environ.get('SITE_URL','').strip().rstrip('/'), SUPA)
AT='ish_at'; RT='ish_rt'; SITE_URL=os.environ.get('SITE_URL','').rstrip('/'); SECURE=os.environ.get('ISHTARIK_SECURE_COOKIES')=='1' or SITE_URL.lower().startswith('https://')
AUTH_ATTEMPTS={}
AUTH_WINDOW=300
AUTH_MAX=8
DB_PATH.parent.mkdir(parents=True,exist_ok=True)
@contextmanager
def db():
 c=sqlite3.connect(DB_PATH,timeout=10); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA journal_mode=WAL')
 try:
  yield c
  c.commit()
 except Exception:
  c.rollback(); raise
 finally:
  c.close()
def init_db():
 with db() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS profiles(id INTEGER PRIMARY KEY,email TEXT NOT NULL UNIQUE COLLATE NOCASE,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS service_status(service_key TEXT PRIMARY KEY,status TEXT NOT NULL,detail TEXT NOT NULL,updated_at INTEGER NOT NULL);
  INSERT OR IGNORE INTO service_status VALUES('ads','not_connected','لم يتم ربط مزود إعلانات معتمد بعد.',strftime('%s','now'));
  INSERT OR IGNORE INTO service_status VALUES('payments','not_connected','لم يتم إعداد مزود دفع أو سحب بعد.',strftime('%s','now'));
  INSERT OR IGNORE INTO service_status VALUES('revenue','disabled','الأرباح النقدية معطلة حتى تأكيد إيراد حقيقي.',strftime('%s','now'));''')
def pwhash(pw):
 salt=secrets.token_bytes(16); key=hashlib.scrypt(pw.encode(),salt=salt,n=2**14,r=8,p=1,dklen=32); return salt.hex()+':'+key.hex()
def verify(pw,encoded):
 try:
  salt,key=encoded.split(':',1); actual=hashlib.scrypt(pw.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1,dklen=32); return hmac.compare_digest(actual.hex(),key)
 except Exception: return False
def digest(t): return hashlib.sha256(t.encode()).hexdigest()
def user_for(t):
 if not t:return None
 with db() as c:
  r=c.execute('SELECT p.id,p.email,p.role FROM sessions s JOIN profiles p ON p.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?',(digest(t),int(time.time()))).fetchone()
 return dict(r) if r else None
class H(BaseHTTPRequestHandler):
 def log_message(self,fmt,*args): print('%s - %s'%(self.address_string(),fmt%args))
 def send(self,data='',status=200,typ='text/html; charset=utf-8',headers=None):
  self.send_response(status); self.send_header('Content-Type',typ); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('X-Frame-Options','DENY'); self.send_header('Referrer-Policy','strict-origin-when-cross-origin'); self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()'); self.send_header('Cross-Origin-Opener-Policy','same-origin'); self.send_header('Cross-Origin-Resource-Policy','same-origin'); self.send_header('X-Permitted-Cross-Domain-Policies','none'); self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"); self.send_header('Cache-Control','no-store');
  if SECURE:self.send_header('Strict-Transport-Security','max-age=31536000; includeSubDomains')
  for k,v in (headers or {}).items():self.send_header(k,v)
  for ck in getattr(self,'_out',[]):self.send_header('Set-Cookie',ck)
  self.end_headers(); self.wfile.write(data if isinstance(data,bytes) else data.encode())
 def js(self,d,status=200):self.send(json.dumps(d,ensure_ascii=False),status,'application/json; charset=utf-8')
 def tok(self):
  c=SimpleCookie()
  try:c.load(self.headers.get('Cookie',''))
  except Exception:pass
  return c[COOKIE].value if COOKIE in c else None
 def cookies(self):
  c=SimpleCookie()
  try:c.load(self.headers.get('Cookie',''))
  except Exception:pass
  return {k:m.value for k,m in c.items()}
 def ck(self,name,val,age):return f'{name}={val}; HttpOnly; SameSite=Lax; Path=/; Max-Age={age}'+('; Secure' if SECURE else '')
 def setauth(self,s):
  self._out=getattr(self,'_out',[])+[self.ck(AT,s['access_token'],int(s.get('expires_in',3600))),self.ck(RT,s['refresh_token'],TTL)]
 def clearauth(self):self._out=getattr(self,'_out',[])+[self.ck(AT,'',0),self.ck(RT,'',0)]
 def mk(self,d,at):
  am=d.get('app_metadata') or {}
  return {'id':d['id'],'email':d.get('email',''),'role':'admin' if am.get('platform_role')=='admin' else 'user','token':at}
 def cur_user(self):
  if hasattr(self,'_u'):return self._u
  if not SUPA:
   self._u=user_for(self.tok());return self._u
  ck=self.cookies();at,rt=ck.get(AT),ck.get(RT);self._u=None;self._down=False
  try:
   if at:
    try:self._u=self.mk(supa.get_user(at),at)
    except supa.SupaError:pass
   if not self._u and rt:
    s=supa.refresh(rt);self._u=self.mk(supa.get_user(s['access_token']),s['access_token']);self.setauth(s)
  except supa.SupaDown:self._down=True
  except supa.SupaError:self.clearauth()
  return self._u
 def form(self):
  try:n=int(self.headers.get('Content-Length','0'))
  except (TypeError,ValueError):
   self.close_connection=True;self.send('طلب غير صالح',400,'text/plain; charset=utf-8',{'Connection':'close'});return None
  if n<0:
   self.close_connection=True;self.send('طلب غير صالح',400,'text/plain; charset=utf-8',{'Connection':'close'});return None
  if n>16384:
   self.close_connection=True;self.send('حجم الطلب أكبر من المسموح',413,'text/plain; charset=utf-8',{'Connection':'close'});return None
  return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf8','replace'),keep_blank_values=True).items()}
 def client_ip(self):
  remote=self.client_address[0]
  # X-Forwarded-For is trusted only when deployment ensures the app is reachable via its proxy only.
  if os.environ.get('TRUST_PROXY')=='1':
   candidate=(self.headers.get('X-Forwarded-For','').split(',')[0]).strip()
   try:return str(ipaddress.ip_address(candidate))
   except ValueError:pass
  return remote
 def redir(self,where,cookie=None,status=303):self.send(b'',status,headers={'Location':where,**({'Set-Cookie':cookie} if cookie else {})})
 def page(self,body,title='إشترك'):
  u=self.cur_user(); auth=(f'<a class="btn ghost" href="/dashboard">حسابي</a><span class="user">{html.escape(u["email"])}</span><form method="post" action="/logout" class="logout-form"><button class="btn ghost" type="submit">خروج</button></form>' if u else '<a class="btn ghost" href="/login">دخول</a><a class="btn primary" href="/register">إنشاء حساب</a>')
  self.send(f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0b0a17"><title>{title} — إشترك</title><link rel="stylesheet" href="/static/style.css"></head><body><header><a class="brand" href="/">إشترك <small>منصة إعلانات شفافة</small></a><nav><a href="/#how">كيف تعمل</a><a href="/#status">حالة الخدمات</a><a href="/ads">الإعلانات</a><a href="/faq">الأسئلة الشائعة</a></nav><div class="actions">{auth}</div></header><main>{body}</main><footer>إشترك · نسخة أولية قابلة للتشغيل <span>الأرباح والسحب غير مفعّلين</span></footer><script src="/static/app.js" defer></script></body></html>''')
 def authpage(self,mode,error='',info=''):
  reg=mode=='register'; title='إنشاء حساب' if reg else 'تسجيل الدخول'; e=(f'<div class="notice error">{html.escape(error)}</div>' if error else '')+(f'<div class="notice">{html.escape(info)}</div>' if info else '')
  body=f'''<section class="auth"><div class="card authcard"><span class="eyebrow">حسابك يبدأ هنا</span><h1>{title}</h1><p class="muted">{'مصادقة Supabase Auth.' if SUPA else 'وضع تطوير محلي: مصادقة SQLite.'}</p>{e}<form method="post" action="/{mode}"><label>البريد الإلكتروني<input name="email" type="email" maxlength="254" autocomplete="email" required></label><label>كلمة المرور<input name="password" type="password" minlength="{10 if reg else 1}" autocomplete="{'new-password' if reg else 'current-password'}" required></label>{'<small class="muted">10 أحرف على الأقل</small>' if reg else ''}<button class="btn primary full">{title}</button></form><p class="switch">{'لديك حساب؟ <a href="/login">دخول</a>' if reg else 'جديد هنا؟ <a href="/register">أنشئ حساباً</a>'}</p>{'<p class="switch"><a href="/reset-password">نسيت كلمة المرور؟</a></p>' if not reg else ''}<p class="muted tiny">لا يمكن إنشاء حساب مشرف من التسجيل العام. </p></div></section>'''; self.page(body,title)
 def do_GET(self):
  path=urlparse(self.path).path
  if path.startswith('/static/'):
   p=(ROOT/'static'/path[8:]).resolve()
   static_root=(ROOT/'static').resolve()
   try:p.relative_to(static_root)
   except ValueError:return self.send('Not found',404)
   if not p.is_file():return self.send('Not found',404)
   t=mimetypes.guess_type(str(p))[0] or 'application/octet-stream'; return self.send(p.read_bytes(),200,t+('; charset=utf-8' if t.startswith('text/') else ''))
  if path=='/health' and SUPA:
   ok=supa.health();return self.js({'ok':ok,'mode':'supabase','auth':'reachable' if ok else 'unreachable','ads':'not_connected','payments':'not_connected'},200 if ok else 503)
  if path=='/health':
   try:
    with db() as c:c.execute('SELECT 1')
    return self.js({'ok':True,'database':'connected','ads':'not_connected','payments':'not_connected'})
   except Exception:return self.js({'ok':False},503)
  if path=='/api/status' and SUPA:
   ok=supa.health();return self.js({'services':[{'service_key':'auth','status':'connected' if ok else 'unreachable','detail':'خدمة المصادقة (Supabase).' if ok else 'تعذر الوصول إلى خدمة المصادقة.'},{'service_key':'ads','status':'not_connected','detail':'لم يتم ربط مزود إعلانات معتمد بعد.'},{'service_key':'payments','status':'not_connected','detail':'لم يتم إعداد مزود دفع أو سحب بعد.'},{'service_key':'revenue','status':'disabled','detail':'الأرباح النقدية معطلة حتى تأكيد إيراد حقيقي.'}]})
  if path=='/api/status':
   with db() as c:r=c.execute('SELECT service_key,status,detail FROM service_status ORDER BY service_key').fetchall()
   return self.js({'services':[dict(x) for x in r]})
  if path=='/logout':return self.send('Method Not Allowed',405,'text/plain; charset=utf-8',{'Allow':'POST'})
  if path in ('/register','/login'):return self.authpage(path[1:])
  u=self.cur_user()
  if path=='/dashboard' and u:
   body=f'''<section class="hero compact"><span class="eyebrow">لوحة حسابك</span><h1>أهلاً بيك 👋</h1><p class="muted">تم تسجيل الدخول بالحساب <b>{html.escape(u['email'])}</b>.</p><div class="notice warn">لا توجد إعلانات مدفوعة أو أرباح أو سحوبات مفعّلة حالياً.</div></section><section class="grid three"><article class="card"><h3>الإعلانات</h3><p>مزود الإعلانات غير مربوط.</p><span class="status">غير مفعّل</span></article><article class="card"><h3>المحفظة</h3><p>لا توجد أرصدة مالية منشأة.</p><span class="status">معطّلة</span></article><article class="card"><h3>السحب</h3><p>لم يُهيأ مزود دفع.</p><span class="status">غير مهيأ</span></article></section><section class="section card"><h2>حالة الخدمات</h2><div id="service-status">جارٍ التحميل…</div></section>''';return self.page(body,'لوحة الحساب')
  if SUPA and path=='/reset-password':
   return self.page('<section class="auth"><div class="card authcard"><h1>استعادة الحساب</h1><form method="post" action="/reset-password"><label>البريد الإلكتروني<input name="email" type="email" maxlength="254" required></label><button class="btn primary full">إرسال رابط الاستعادة</button></form></div></section>','استعادة الحساب')
  if SUPA and path=='/update-password':
   return self.page('<section class="auth"><div class="card authcard"><h1>كلمة مرور جديدة</h1><form method="post" action="/update-password" id="pw"><input type="hidden" name="access_token" id="tk"><label>كلمة المرور الجديدة<input name="password" type="password" minlength="10" autocomplete="new-password" required></label><button class="btn primary full">حفظ</button></form></div></section><script src="/static/recover.js" defer></script>','كلمة مرور جديدة')
  if path=='/reset-password':
   return self.page('<section class="auth"><div class="card authcard"><h1>استعادة الحساب</h1><p class="muted">هذه الميزة غير مفعّلة بعد. يلزم إعداد خدمة بريد/مصادقة وإرسال رابط آمن لإعادة التعيين.</p><a class="btn ghost full" href="/login">العودة للدخول</a></div></section>','استعادة الحساب')
  if path in ('/ads','/wallet','/withdrawals','/profile','/notifications','/support','/faq','/terms','/privacy','/admin'):
   if SUPA and not u and getattr(self,'_down',False):return self.send('خدمة المصادقة غير متاحة حالياً',503,'text/plain; charset=utf-8')
   if path in ('/ads','/wallet','/withdrawals','/profile','/notifications','/support','/admin') and not u:return self.redir('/login')
   titles={'/ads':'الإعلانات المتاحة','/wallet':'المحفظة','/withdrawals':'طلبات السحب','/profile':'الملف الشخصي','/notifications':'الإشعارات','/support':'مركز الدعم','/faq':'الأسئلة الشائعة','/terms':'الشروط والأحكام','/privacy':'سياسة الخصوصية','/admin':'لوحة الإدارة'}
   if SUPA and getattr(self,'_down',False):return self.send('خدمة المصادقة غير متاحة حالياً',503,'text/plain; charset=utf-8')
   if path=='/admin' and u.get('role')!='admin':return self.send('ممنوع — صلاحية المشرف مطلوبة',403,'text/plain; charset=utf-8')
   if SUPA and path in pages_supa.RENDER:return self.page(f'<section class="section"><span class="eyebrow">إشترك · {titles[path]}</span><h1>{titles[path]}</h1>{pages_supa.RENDER[path](u)}</section>',titles[path])
   content={
    '/ads':'<div class="notice warn">مزود الإعلانات غير مربوط. لا توجد إعلانات مدفوعة متاحة حالياً، ولن يُحتسب أي ربح.</div>',
    '/wallet':'<div class="grid three"><article class="card"><h3>الرصيد المعلّق</h3><p>لا توجد بيانات مؤكدة.</p></article><article class="card"><h3>المتاح للسحب</h3><p>غير متاح حالياً.</p></article><article class="card"><h3>سجل المعاملات</h3><p>لا توجد معاملات مالية مسجلة.</p></article></div>',
    '/withdrawals':'<div class="notice warn">طلبات السحب معطّلة حتى ربط مزود دفع مناسب واختباره. لا ترسل معلومات مالية حساسة هنا.</div>',
    '/profile':f'<div class="card"><p>البريد: <b>{html.escape(u["email"])}</b></p><p>الدور: {html.escape(u["role"])}</p><p class="muted">تعديل الملف والتحقق من البريد واستعادة الحساب تحتاج ربط خدمة مصادقة إنتاجية.</p></div>',
    '/notifications':'<div class="card">لا توجد إشعارات حالياً.</div>',
    '/support':'<div class="card"><h3>الدعم</h3><p>مركز الدعم قيد الإعداد. لا توجد تذاكر محفوظة في هذه النسخة.</p></div>',
    '/faq':'<details class="card"><summary>هل الأرباح مفعّلة؟</summary><p>لا، حتى الآن لا يوجد مزود إعلانات معتمد أو إيراد مؤكد.</p></details><details class="card"><summary>هل أستطيع السحب؟</summary><p>لا، الدفع والسحب غير مفعّلين.</p></details><details class="card"><summary>هل 65/35 ضمان للربح؟</summary><p>لا. النسبة المستهدفة تطبق فقط على الإيراد الصافي المؤهل بعد تأكيده.</p></details>',
    '/terms':'<div class="card"><p>هذه نسخة تطوير. لا تقدم المنصة حالياً خدمة إعلانات مدفوعة أو أرباحاً أو سحوبات. لا تعتبر هذه الصفحة شروطاً قانونية نهائية؛ يلزم إعداد ومراجعة قانونية قبل الإطلاق.</p><p>سياسة التقريب المقترحة: تُقرّب حصة المستخدم إلى الأسفل إلى منزلتين عشريتين، ويُخصّص باقي الإيراد المؤهل للمنصة، بحيث لا يتجاوز مجموع الحصتين الإيراد الصافي المؤكد. هذا وصف للقاعدة البرمجية المقترحة وليس وعداً بعائد.</p><p>سياسة عكس الإيراد المقترحة: إذا تجاوز مبلغ العكس الرصيد المتاح، يُحجز الجزء الممكن من الرصيد ويُسجّل الباقي كدين منفصل؛ تُخصّص الأرباح المؤهلة اللاحقة لتسوية الدين قبل إضافة رصيد قابل للسحب، ويُمنع السحب ما دام الدين قائماً. هذه السياسة غير مفعّلة في قاعدة الإنتاج حتى اجتياز اختبارات قاعدة البيانات المعزولة.</p></div>',
    '/privacy':'<div class="card"><p>تُخزّن هذه النسخة المحلية بيانات الحساب في قاعدة SQLite على الجهاز/الخادم الذي يشغّلها. لا تنشرها للإنترنت قبل إعداد HTTPS وسياسة خصوصية نهائية وضوابط الاحتفاظ بالبيانات.</p></div>',
    '/admin':'<div class="notice warn">لوحة الإدارة المحلية. لا توجد إحصاءات مالية مؤكدة بعد. لا يمكن منح دور المشرف من التسجيل العام.</div><div class="grid three"><article class="card"><h3>الحسابات</h3><p>تُقرأ من قاعدة البيانات المحلية فقط عند إعداد صلاحية الإدارة.</p></article><article class="card"><h3>الإعلانات</h3><p>المزود غير مربوط.</p></article><article class="card"><h3>السحب</h3><p>معطّل.</p></article></div>'}
   return self.page(f'<section class="section"><span class="eyebrow">إشترك · {titles[path]}</span><h1>{titles[path]}</h1>{content[path]}</section>',titles[path])
  if path=='/dashboard' and not u:return self.redir('/login')
  if path not in ('/','/dashboard'):return self.send('Not found',404)
  notice=('<div class="notice warn">تم حذف جلسة هذا المتصفح، لكن تعذّر تأكيد إبطال الجلسة لدى مزود المصادقة. أعد المحاولة عند استقرار الاتصال.</div>' if urlparse(self.path).query=='logout=local-only' else '')
  body=notice+'''<section class="hero"><div><span class="eyebrow">● الشفافية أولاً</span><h1>شاهد بوضوح.<br><span class="gradient">واكسب فقط عند التأكيد.</span></h1><p class="lead">منصة عربية قيد البناء، هدفها توزيع الإيراد المؤهل بشفافية. لا نعدك بأرباح قبل ربط مزود حقيقي والتحقق من الإيرادات.</p><div class="heroactions"><a class="btn primary" href="/register">ابدأ بإنشاء حساب</a><a class="btn ghost" href="#how">اكتشف طريقة العمل</a></div><p class="muted">✓ لا أرباح وهمية　 ✓ سجل واضح　 ✓ الدفع غير مفعّل حالياً</p></div><div class="card preview"><span class="eyebrow">مركز الشفافية · الحالة الحالية</span><div class="big">—</div><p class="muted">الإيرادات المؤكدة: لا توجد بيانات موثوقة بعد</p><div class="grid two"><div class="tile">الإعلانات<b>غير مربوط</b></div><div class="tile">الدفع<b>غير مهيأ</b></div><div class="tile">المحفظة<b>غير مفعّلة</b></div><div class="tile">البيانات<b>حقيقية فقط</b></div></div><small class="muted">هذه حالة النظام وليست أرقاماً تجريبية.</small></div></section><section id="how" class="section"><h2>كيف تعمل المنصة؟</h2><p class="muted">لن تُفعّل أي خطوة مالية قبل استيفاء متطلبات المزود والاختبارات.</p><div class="grid three"><article class="card"><b class="num">01</b><h3>إعلان معتمد</h3><p>ربط مزود يسمح صراحةً بالمكافآت النقدية والتحقق من المشاهدة.</p></article><article class="card"><b class="num">02</b><h3>إيراد مؤكد</h3><p>استلام بيانات الإيراد الفعلي من مصدر موثوق ومنع التكرار.</p></article><article class="card"><b class="num">03</b><h3>توزيع موثق</h3><p>احتساب الحصص بعد التأكيد فقط وفق الاتفاقية والإعدادات.</p></article></div><div class="notice">مثال حسابي توضيحي فقط: من 1.00 دولار إيراد صافٍ مؤهل، 0.65 دولار للمشاهد و0.35 دولار للمنصة. هذا ليس وعداً بعائد لكل مشاهدة.</div></section><section id="status" class="section"><h2>حالة الخدمات</h2><div id="service-status">جارٍ قراءة الحالة من الخادم…</div></section><section id="faq" class="section"><h2>أسئلة شائعة</h2><details class="card"><summary>هل أستطيع الربح الآن؟</summary><p>لا. الأرباح والسحب غير مفعّلين.</p></details><details class="card"><summary>هل نسبة 65% مضمونة؟</summary><p>هي النسبة المستهدفة في المواصفات وليست وعداً بعائد.</p></details></section>''';self.page(body)
 def origin_ok(self,strict):
  host=self.headers.get('Host','');ok={f'http://{host}',f'https://{host}'}
  if SITE_URL:ok.add(SITE_URL)
  o=self.headers.get('Origin');r=self.headers.get('Referer')
  if o:return o.rstrip('/') in ok
  if r:return any(r.startswith(x+'/') for x in ok)
  return not strict
 def do_POST(self):
  path=urlparse(self.path).path
  AUTHP=('/register','/login','/reset-password','/update-password');DATAP=('/profile','/support','/logout')
  if path not in AUTHP+DATAP:return self.send('Not found',404,'text/plain; charset=utf-8')
  if not self.origin_ok(True):return self.send('طلب مرفوض: مصدر غير موثوق',403,'text/plain; charset=utf-8')
  now=int(time.time()); ip=self.client_ip(); ipath=(ip,path)
  if len(AUTH_ATTEMPTS)>10000:
   for key,vals in list(AUTH_ATTEMPTS.items()):
    keep=[v for v in vals if now-v<AUTH_WINDOW]
    if keep:AUTH_ATTEMPTS[key]=keep
    else:AUTH_ATTEMPTS.pop(key,None)
  attempts=[x for x in AUTH_ATTEMPTS.get(ipath,[]) if now-x<AUTH_WINDOW]
  limit=AUTH_MAX if path in AUTHP else 30
  if len(attempts)>=limit:
   self.send('محاولات كثيرة. انتظر خمس دقائق ثم أعد المحاولة.',429,'text/plain; charset=utf-8',{'Retry-After':'300'}); return
  attempts.append(now); AUTH_ATTEMPTS[ipath]=attempts
  d=self.form()
  if d is None:return
  if SUPA:return self.post_supa(path,d)
  if path in ('/register','/login','/logout'):return self.post_local(path,d)
  return self.send('Not found',404,'text/plain; charset=utf-8')
 def post_supa(self,path,d):
  email=d.get('email','').strip().lower(); pw=d.get('password','')
  try:
   if path=='/logout':
    at=self.cookies().get(AT)
    try:remote_ok=supa.logout(at) if at else True
    except Exception:remote_ok=False
    self.clearauth()
    return self.redir('/' if remote_ok else '/?logout=local-only')
   if path=='/register':
    if len(email)>254 or '@' not in email or len(pw)<10:return self.authpage('register','أدخل بريداً صحيحاً وكلمة مرور من 10 أحرف على الأقل.')
    r=supa.signup(email,pw,SITE_URL+'/login' if SITE_URL else None)
    if r.get('access_token'):self.setauth(r);return self.redir('/dashboard')
    return self.authpage('login',info='إن كان البريد صالحاً فستصلك رسالة تأكيد. أكّد بريدك ثم سجّل الدخول.')
   if path=='/login':
    if len(email)>254 or '@' not in email or not pw:return self.authpage('login','أدخل البريد وكلمة المرور.')
    self.setauth(supa.login(email,pw));return self.redir('/dashboard')
   if path=='/reset-password':
    if len(email)<=254 and '@' in email:
     try:supa.recover(email,SITE_URL+'/update-password' if SITE_URL else None)
     except supa.SupaError as e:
      if e.status==429:raise
    return self.authpage('login',info='إن كان البريد مسجلاً فسيصلك رابط الاستعادة.')
   if path=='/update-password':
    tk=d.get('access_token','')
    if not tk or len(pw)<10:return self.authpage('login','الرابط غير صالح أو كلمة المرور قصيرة.')
    supa.update_password(tk,pw);return self.authpage('login',info='تم تغيير كلمة المرور. سجّل الدخول.')
   u=self.cur_user()
   if not u:return self.redir('/login')
   if path=='/profile':
    supa.rest('PATCH','profiles',u['token'],{'id':'eq.'+u['id']},body={'display_name':pages_supa.clean(d.get('display_name'),80)});return self.redir('/profile')
   if path=='/support':
    sub=pages_supa.clean(d.get('subject'),180);msg=pages_supa.clean(d.get('message'),5000)
    if not sub or not msg:return self.page('<section class="section"><div class="notice error">املأ الموضوع والرسالة.</div></section>','الدعم')
    supa.rest('POST','support_tickets',u['token'],body={'user_id':u['id'],'subject':sub,'message':msg});return self.redir('/support')
  except (supa.SupaError,supa.SupaDown) as e:
   m=supa.ar_error(e);st=503 if isinstance(e,supa.SupaDown) else 200
   if path in ('/register','/login'):return self.authpage(path[1:],m)
   return self.send(m,st if st!=200 else 400,'text/plain; charset=utf-8')
  return self.send('Not found',404,'text/plain; charset=utf-8')
 def post_local(self,path,d):
  email=d.get('email','').strip().lower(); pw=d.get('password','')
  if path=='/logout':
   tok=self.tok()
   if tok:
    with db() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(digest(tok),))
   self._out=getattr(self,'_out',[])+[f'{COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'+('; Secure' if SECURE else '')]
   return self.redir('/')
  if path=='/register':
   if len(email)>254 or '@' not in email or len(pw)<10:
    self.authpage('register','أدخل بريداً صحيحاً وكلمة مرور من 10 أحرف على الأقل.'); return
   try:
    with db() as c:
     cur=c.execute("INSERT INTO profiles(email,password_hash,role,created_at) VALUES(?,?,'user',?)",(email,pwhash(pw),int(time.time()))); uid=cur.lastrowid
     tok=secrets.token_urlsafe(32); now=int(time.time());c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(digest(tok),uid,now+TTL,now))
    return self.redir('/dashboard',f'{COOKIE}={tok}; HttpOnly; SameSite=Lax; Path=/; Max-Age={TTL}')
   except sqlite3.IntegrityError:
    self.authpage('register','هذا البريد مسجل مسبقاً.'); return
  with db() as c:r=c.execute('SELECT id,password_hash FROM profiles WHERE email=?',(email,)).fetchone()
  if not r or not verify(pw,r['password_hash']):
   self.authpage('login','بيانات الدخول غير صحيحة.'); return
  tok=secrets.token_urlsafe(32);now=int(time.time())
  with db() as c:c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(digest(tok),r['id'],now+TTL,now))
  return self.redir('/dashboard',f'{COOKIE}={tok}; HttpOnly; SameSite=Lax; Path=/; Max-Age={TTL}')
if __name__=='__main__':
 print(f'إشترك running at http://{HOST}:{PORT} (auth: '+('supabase' if SUPA else 'local sqlite')+')')
 if not SUPA:init_db();print(f'Database: {DB_PATH}')
 ThreadingHTTPServer((HOST,PORT),H).serve_forever()
