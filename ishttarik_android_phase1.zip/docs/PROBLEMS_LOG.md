# سجل المشكلات — المرحلة الثامنة

تاريخ الفحص: 2026-10-13. النطاق: نسخة `ishttarik_phase7.zip` فقط؛ لا تغييرات على الإنتاج في هذه الجولة.

## P8-001 — لا توجد بيئة Docker/Supabase محلية متاحة
- **المشكلة:** تعذر تشغيل `supabase start` لتشغيل Postgres وGoTrue وPostgREST وInbucket محلياً.
- **السبب الجذري المثبت:** `docker --version` و`supabase --version` أعادا `command not found`، ولا يوجد `/var/run/docker.sock`. لذلك لا يوجد Docker daemon يمكن للـ CLI استخدامه.
- **دليل إضافي:** فشل DNS لـ `registry-1.docker.io` و`github.com` و`supabase.com` برسالة `Temporary failure in name resolution`؛ لذلك لا يمكن تثبيت الأدوات أو تنزيل الصور من هذه البيئة.
- **الإجراء:** لم أدّعِ نجاح تشغيل محلي، ولم أجرّب كتابة معاملات مالية على الإنتاج كبديل. يجب إعادة هذه الخطوات في Codespaces أو بيئة أخرى تحتوي Docker فعالاً واتصالاً شبكياً.
- **الاختبار الذي يثبت الحالة:** فحص الأدوات وDocker socket و`socket.getaddrinfo`. هذه فحوص بيئة وليست اختباراً للتطبيق.

## P8-002 — اختبارات التطبيق المحلية
- **المشكلة:** التأكد من أن نسخة التسليم لا تكسر الاختبارات الموجودة.
- **السبب الجذري:** لا مشكلة في الاختبارات المحلية الحالية.
- **الإصلاح:** لا تعديل على منطق التطبيق في هذه الجولة؛ أُعيد فك ZIP في مجلد جديد وشُغّل compile والاختبارات.
- **الاختبار:** `python3 -m py_compile app.py supa.py pages_supa.py ledger.py` نجح. `python3 -m unittest discover -s tests -v` أعاد `Ran 35 tests in 1.440s` ثم `OK` (35 ناجحة، 0 فاشلة). هذه اختبارات محلية/محاكاة وليست دليلاً على تشغيل Supabase الحقيقي.

## P8-003 — ترحيل فصل دين العكس لم يُختبر على PostgreSQL
- **المشكلة:** الملف `supabase/proposed_migrations/20261013000100_separate_reversal_debt.sql` يغيّر منطق دفتر الأستاذ والسحب والتسوية والعكس.
- **السبب الجذري:** لا يوجد PostgreSQL/Supabase محلي يعمل في هذه البيئة، ولا يجوز اختبار هذه الكتابات المالية على قاعدة الإنتاج.
- **الإجراء:** بقي الملف في `proposed_migrations` ولم يُنقل إلى `supabase/migrations` ولم يُطبّق على الإنتاج. لا تعتبر سياسة الدين جاهزة للإنتاج.
- **اختبار الإثبات:** اختبارات Python الثلاثة الخاصة بالدين نجحت ضمن 35/35، لكنها لا تثبت SQL أو أقفال PostgreSQL أو التزامن. لا يوجد اختبار SQL فعلي في هذه الجولة.
- **ملاحظة مراجعة ساكنة:** دالة `reverse_revenue` في الترحيل المقترح تقفل صف الإيراد قبل أخذ قفل advisory للمستخدم/العملة، بينما `settle_revenue` يأخذ قفل advisory قبل التعامل مع صف الإيراد. اختلاف ترتيب الأقفال قد يسبب deadlock عند التداخل؛ يلزم توحيد ترتيب الأقفال ثم اختبار التزامن على PostgreSQL قبل اعتماد الترحيل.

## P8-004 — الاختبارات الحقيقية للبريد وHTTP وRLS والتزامن غير متاحة
- **المشكلة:** اختبارات Auth/REST/Inbucket وتزامن 20 اتصالاً فعلياً.
- **السبب الجذري:** لم يبدأ Supabase المحلي بسبب P8-001؛ لا توجد endpoints محلية ولا Inbucket.
- **الإجراء:** لم أنشئ مستخدمين أو صفوفاً مالية على الإنتاج، ولم أسمِّ اختبارات المحاكاة اختبارات حقيقية.
- **الاختبار الذي يثبت الحالة:** عدم وجود CLI/Docker/Docker socket وفشل DNS. البنود الحقيقية ما زالت غير مكتملة.

## P8-005 — Docker/HTTPS/النسخ الاحتياطي والتراجع غير منفّذة
- **المشكلة:** بناء الصورة وتشغيل Compose/Caddy والتحقق من HTTPS والصحة وإعادة التشغيل والنسخ والاستعادة والتراجع.
- **السبب الجذري:** Docker غير متاح ولا يوجد daemon أو اتصال registry.
- **الإجراء:** لم أزعم نجاح build أو compose أو HTTPS؛ ملفات Docker الحالية إعدادات فقط.
- **الاختبار الذي يثبت الحالة:** أوامر `docker` غير موجودة وDocker socket غير موجود.

## P8-006 — فحص تاريخ Git والتبعيات غير مكتمل
- **المشكلة:** فحص تاريخ Git وفحص تبعيات شامل.
- **السبب الجذري:** التسليم ZIP بلا `.git` ولا توجد أداة Docker أو فاحص حاويات مثبت، كما لا يوجد DNS لتثبيت أدوات.
- **الإجراء:** فحص ملفات النسخة فقط؛ لا يمكن استنتاج سلامة تاريخ Git من ZIP.
- **الاختبار الذي يثبت الحالة:** فحص محتويات الأرشيف لا يُظهر مجلد `.git`، وأدوات Docker/Supabase غير متاحة.

## P8-007 — الإنتاج بقي دون تغييرات في هذه الجولة
- **الإجراء/التحقق:** استعلام قراءة فقط إلى Supabase أعاد `auth_users=0`, `revenue_records=0`, `wallet_transactions=0`, `withdrawal_requests=0`, `revenue_enabled=false`, `withdrawals_enabled=false`. استعلام قائمة الفروع في هذه الجولة أعاد `main` فقط؛ لم يُنشأ فرع اختبار جديد في المرحلة الثامنة.
- **حدود الإثبات:** هذا الاستعلام يثبت هذه الجداول والأعلام في لحظة الفحص، ولا يثبت صفراً في كل جدول أو عدم وجود عمليات خارجية أخرى.

## AND-001 — Android app scaffold added, build not run
- **Status:** partial. Kotlin/Compose starter, CI workflow draft, and original branding assets added.
- **Constraint:** no connected GitHub repository was returned by the GitHub connector; no commit/release was created. This environment has not executed Gradle, Android SDK emulator, or signing.
- **Security choice:** no keystore, Firebase service account, Supabase service-role key, or `.env` is packaged. Unimplemented microphone/camera/biometric permissions are not declared in the current manifest.
- **Next:** run CI in the private repository, fix all errors, then implement Supabase and FCM in separately tested steps.
