# Android phase 1 — truthful status

Date: 2026-10-14. Source baseline: uploaded `ishttarik_phase8.zip`.

## Implemented in source scaffold
- Native Kotlin/Compose application skeleton with Arabic RTL-capable layout and dark purple/pink/cyan palette.
- A small home/wallet/settings/support-preview UI.
- `minSdk 26`, `targetSdk 36`, `allowBackup=false`, `usesCleartextTraffic=false`.
- Notification channels and an explicitly local-only notification example.
- Original SVG and PNG brand assets under `branding/`.
- GitHub Actions workflow draft for lint, unit tests, emulator tests on API 26 and 36, release signing from secrets, `apksigner verify`, SHA-256 and tag release.

## Not implemented / not verified
- No Gradle build, lint, APK, signature, emulator, or real-device run was performed in this environment.
- Supabase mobile auth/REST/storage integration is not connected.
- FCM HTTP v1 server integration, token table/migration, database webhook, and Edge Function are not connected.
- Microphone, camera, biometric, photo picker/SAF, upload, encrypted session, certificate pinning, notification deep links, and financial view queries are not implemented.
- GitHub connector returned an empty repository list; no repository was created or changed from this session. A GitHub Release URL cannot exist until the project is placed in a private repo and CI succeeds.
- No production Supabase migration was applied; production flags remain out of scope and must stay false.

## Required CI secrets (never commit values)
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
- Later for FCM: service-account JSON stored as a GitHub secret and consumed only by a server-side Supabase Edge Function; never add it to the Android app or repository.
- Firebase `google-services.json` should not be committed in this workflow; for FCM, prefer a controlled CI secret/file step or configure Firebase's supported client config process. Public client configuration is not a server credential, but do not include it until the Firebase project is supplied.

## Next step
Import this folder to a **private** GitHub repository, run the workflow, fix every build/test failure, and only then proceed to Supabase integration and signed release. This package is a starter scaffold, not the completed app.
