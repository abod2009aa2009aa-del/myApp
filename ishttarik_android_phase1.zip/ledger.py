"""Reference implementation of the money rules (Decimal, no floats).
The authoritative logic lives in Postgres (migration 20261012000400); this module is used by tests
and by the e2e script to cross-check the database results. Nothing here moves money."""
from decimal import Decimal, ROUND_DOWN, InvalidOperation

CREDIT = {'earning', 'adjustment', 'withdrawal_release'}
DEBIT = {'withdrawal_hold', 'reversal'}

def dec(x):
    try: return Decimal(str(x))
    except InvalidOperation: raise ValueError('invalid amount')

def split(net, user_bps=6500, places=2, rounding=ROUND_DOWN):
    """Return (user_share, platform_share) of a confirmed NET amount.
    The user share is rounded DOWN (never overpay); the platform gets the exact remainder,
    so user + platform == net with no rounding leak."""
    net = dec(net)
    if net < 0: raise ValueError('net must be >= 0')
    if not 0 <= int(user_bps) <= 10000: raise ValueError('bps out of range')
    q = Decimal(1).scaleb(-places)
    if net != net.quantize(q): raise ValueError('net has more decimals than the currency allows')
    user = (net * int(user_bps) / Decimal(10000)).quantize(q, rounding=rounding)
    return user, net - user

def balances(rows):
    """{currency: {available, pending, held}} from ALL wallet_transactions rows of one user."""
    out = {}
    for r in rows:
        c = r['currency']; a = dec(r['amount']); t = r['transaction_type']; s = r['status']
        b = out.setdefault(c, {'available': Decimal(0), 'pending': Decimal(0), 'held': Decimal(0)})
        if s == 'posted':
            if t in CREDIT: b['available'] += a
            elif t in DEBIT: b['available'] -= a
            if t == 'withdrawal_hold': b['held'] += a
            elif t in ('withdrawal_release', 'withdrawal_paid'): b['held'] -= a
        elif s == 'pending' and t in ('earning', 'adjustment'):
            b['pending'] += a
    return out

def apply_reversal(available, reversal_amount, outstanding_debt=0):
    """Split a revenue reversal between spendable balance and separately tracked debt.

    Returns (ledger_reversal, added_debt); neither value is negative.
    """
    available, reversal_amount, outstanding_debt = map(dec, (available, reversal_amount, outstanding_debt))
    if min(available, reversal_amount, outstanding_debt) < 0:
        raise ValueError('amounts must be >= 0')
    posted = min(available, reversal_amount)
    return posted, reversal_amount - posted

def apply_earning_to_debt(earning, outstanding_debt=0):
    """Offset new earnings against reversal debt before making funds available.

    Returns (available_earning, debt_paid, debt_remaining).
    """
    earning, outstanding_debt = map(dec, (earning, outstanding_debt))
    if min(earning, outstanding_debt) < 0:
        raise ValueError('amounts must be >= 0')
    paid = min(earning, outstanding_debt)
    return earning - paid, paid, outstanding_debt - paid

def can_withdraw(available, amount, minimum, has_open_request, enabled, outstanding_debt=0):
    amount = dec(amount)
    if not enabled: return False, 'withdrawals_disabled'
    if dec(outstanding_debt) > 0: return False, 'outstanding_reversal_debt'
    if amount <= 0 or amount != amount.quantize(Decimal('0.01')): return False, 'invalid_amount'
    if amount < dec(minimum): return False, 'below_minimum'
    if has_open_request: return False, 'open_request_exists'
    if dec(available) < amount: return False, 'insufficient_balance'
    return True, 'ok'
